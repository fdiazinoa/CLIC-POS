# Recuperación de operaciones pendientes POS — auditoría y contrato propuesto

> Revisión vigente: [respuesta ERP a POS J4](response-j4.md), intención v2 y límites de subperfiles. Solo documentación; acuerdos provisionales y cierre NOT_GRANTED.

> Revisión vigente: [respuesta ERP a POS J3](response-j3.md), intenciones, perfiles y propuesta de raíz durable. Solo documentación; UNAGREED y cierre NOT_GRANTED.

> Revisión vigente: [respuesta ERP a POS J2](response-j2.md). Comparación UTF-16 y canonicalización documental corregidas, sin cambiar vectores históricos. Acuerdos todavía provisionales; cierre NOT_GRANTED.

> Revisión posterior R4: [invariantes conjuntas y una revisión por operación](r4-invariants-response.md). Esta precisión sustituye la unicidad por terna y las verificaciones aisladas del candidato; sigue siendo propuesta UNAGREED.

> Actualización vigente: [respuesta ERP R4 a los 11 puntos POS](response-r4.md). Perfiles candidate-v2 y evidencia sintética verificable; los acuerdos operacionales siguen pendientes. Legacy UNKNOWN y cierre NOT_GRANTED.

Estado: **PROPUESTA PARA VALIDACIÓN; NO LISTO PARA IMPLEMENTAR EN POS**. Fecha: 2026-09-06.

Revisión vigente: [R3 — comparación POS, originales y acuerdos pendientes](review-r3.md). Incluye tabla de cambios respecto a los ZIP revisados, matriz operacional por tipo y preguntas concretas a POS. Las capturas iniciales de esta auditoría se conservan como evidencia histórica.
No se implementaron endpoints, migraciones ni cambios comerciales. No se ejecutaron ventas, cierres, reprocess, backfills, emisión fiscal ni escrituras en Supabase. Los ejemplos son datos sintéticos en archivos.

## Revisión y evidencia

- Worktree ERP aislado, rama `feature/sync-pending-day-recovery-contract`, base `origin/clean-erp` = `adc02d4f9831120f5b0c4265d8b058feb341710f` después de fetch.
- Referencia del prompt: `689ada57f5c5c1d35c327607295892aef40a47db`. Diferencia: `44dfc1dd` y merge `adc02d4f`, únicamente `src/components/finance/PosZReportDetailModal.tsx` y su test (90 inserciones, 20 eliminaciones). Ningún cambio de backend entre ambas revisiones.
- Se leyeron `AGENTS.md`, `CODEX_HANDOVER.md` y `docs/setup-terminal-api.md`. El código actual prevalece sobre las notas históricas de handover.
- POS `5993b1fed18c230dde89734e91fa94e0a95ce2bc` es **referencia aportada**, no checkout verificado aquí: el alcance exige trabajar exclusivamente en ERP. El hilo POS ratificó mediante el usuario la ausencia de sesión durable, openedAt que excluye abonos, abonos fuera del cálculo actual y falta de manifiesto persistido. Es ratificación del hilo POS, no lectura independiente de su checkout. Los esquemas originales por tipo y la comparación ejecutable con tipos/cálculos POS siguen pendientes. La recuperación no autoriza corregir el cálculo.
- No se verificó SHA desplegado, variables de entorno ni flags de producción. Esquema consultado no equivale a versión del servidor desplegado.
- [SQL de solo lectura](evidence-readonly.sql) y [resultado agregado](evidence-result.json): proyecto indicado `cdfdgxejnbznjxuokrrx`, PostgreSQL 17.6, captura **2026-09-06 15:51:35.819268 UTC**. Una sola sentencia SELECT para esta evidencia final; las consultas exploratorias anteriores son instantes distintos. No se eligió empresa ni se extrajeron documentos, clientes, tokens o datos personales.
- `origin/develop...origin/clean-erp` tiene 142 / 4040 commits exclusivos en las referencias locales: una PR desde esta base hacia develop no sería una entrega aislada. Destino de publicación pendiente; no se mezclan ramas para resolverlo.

Clasificación: **C** código comprobado en SHA anterior; **E** catálogo real; **O** forma/agregado observado en la captura; **P** propuesta o verificación pendiente. Los enlaces de fuente siguientes son relativos a esta rama; sus líneas se refieren al SHA auditado.

| Evento | Estado y cantidad en captura final |
|---|---|
| SALE_POSTED | 1.233 APPLIED, 38 FAILED = **1.271** (1.270 a las 15:49 UTC) |
| PAYMENT_POSTED | 1.188 APPLIED, 48 FAILED = **1.236** (1.235 a las 15:49 UTC) |
| SALES_CREDIT_NOTE_POSTED | 13 APPLIED |
| CASH_CLOSE_POSTED | 26 APPLIED, 50 RECEIVED |
| CASH_MOVEMENT_POSTED | 4 RECEIVED |
| WALLET_MOVEMENT_POSTED | 9 RECEIVED |
| Otros canales | INVENTORY_MOVEMENT_POSTED (48), INVOICE_AUDIT_RECORDED (8), TRANSACTION_CREATED (3), SALE_CREATED (1) |

Los 1.262/1.227 del prompt son evidencia histórica, no discrepancia por pérdida demostrada. Los conteos globales incluyen **13 ventas `UBER_EATS_MARKETPLACE`** y canales con forma distinta. No usarlos para cobertura de una terminal. Ningún SALE/NC observado tiene `transaction.zReportId`; los 76 Z no tienen `report.transactionIds` ni `report.collectionIds`. De 42 Z con `cashMovementDetails` array, 41 vacíos y 1 no vacío. Se buscaron también claves equivalentes en raíz/summary/transaction/report/movement, para todos los tipos: aparece `report.source_z_report_id` en 76 Z, `transaction.globalSequence` y algunos `transaction.closedAt`; ninguno demuestra un manifiesto exacto. La búsqueda no demuestra ausencia dentro de todo objeto arbitrariamente anidado ni de otros sistemas externos.

## Matriz de cobertura y transformaciones

Todas las filas terminan en **recuperación exacta de jornada no disponible hoy**; recuperar una copia recibida individual es distinto de probar conjunto completo.

| Dato requerido | Fuente exacta, ruta y momento | Conservado / perdido por transformación | Hoy / mínimo necesario | Evidencia |
|---|---|---|---|---|
| Venta, IDs, líneas, extras | [syncInbox.js](../../server/routes/syncInbox.js), `deriveTransactionEvents` L3931; POST `/api/sync/transactions` L7018, o batch L9541; `erp_sync_inbox.payload.transaction`, cuando POS envía | Original recibido completo como objeto; `buildPosEventEnvelope` L2908 enriquece contexto; [posSaleEventContract.js](../../server/services/posSaleEventContract.js) L198 deriva summary y respeta summary suministrado. No fabrica líneas faltantes | Copia de versión recibida, sin historial demostrado; 1 venta sin items no vacíos en consulta inicial. Original inmutable + revisiones | C/E/O |
| Impuestos/descuentos/precios | `transaction.items`, `taxAmount`, `discountAmount`, snapshot histórico; [posEventApplier.js](../../server/services/posEventApplier.js) L2432–2650, L2781 `insertPosDocumentLines` → `erp_sales_document_items` | Maestro resuelto, redondeo, distribución de impuestos; fallback L2817 solo document_id/item_id/cantidad/precio_unitario/impuesto: pierde IDs de línea, metadata, descuentos, detalle fiscal y extras | No reconstruir POS desde factura ERP ni catálogo actual; preservar original y configuración de cálculo histórica | C |
| Pagos y cambio | `transaction.payments[]` original; evento `PAYMENT_POSTED.payload.payments` = settlementPayments, misma venta, L3953 | `amount`, `amountOriginal`, `currencyCode`, tasa histórica, `appliedAmount`, cambio y moneda se conservan **si llegaron**. Summary y recibo derivado no son copia equivalente. [posEventApplier.js](../../server/services/posEventApplier.js) L4075 proyecta recibo/asientos y saldos | Importar pagos embebidos una vez; PAYMENT_POSTED solo aporta procedencia/estado por efecto. Sin transacción original: PAYMENT_REFERENCE, no cobrar ni sintetizar venta | C/O/P |
| Devolución/NC/anulación | `deriveTransactionEvents` L3931 decide NC por REFUND/B04/E34 con compliance; `payload.transaction`; `applySalesCreditNotePosted` L4259 | Se conservan relaciones suministradas, affectedNCF y estado; reenvío mismo eventId preserva original anterior. No canal durable de mutaciones/VOID probado | Versionar mutaciones y relación al documento original; tombstone de VOID, no borrar. Referencia cerrada read-only o dependencia faltante | C/P |
| Entrada/salida/fondo | POST `/api/sync/cash/movements` L7258; `deriveCashMovementEvents` L4040; `payload.movement` | Summary lee concept/createdAt y puede poner hora de recepción; original POS usa reason/timestamp según prompt. `z_report_id` summary observado vacío en 4 | Restaurar reason/timestamp y moneda del original; no sustituir por summary. `fixedCashFundAmount` no acredita ingreso; exigir movimiento explícito, incluso fondo cero si registrado | C/O/P |
| Abono CxC y allocations POS | No ruta equivalente encontrada entre sync/pos. [syncMasterCollections.js](../../server/services/syncMasterCollections.js) L1133: `collections` devuelve `catalog.product_groups`; [salesRouteService.js](../../server/services/salesRouteService.js) L643 y [salesRoutes.js](../../server/routes/salesRoutes.js) L91: cobros de visita | `erp_sales_route_collections` tiene operation_id/visit_id/amount/currency_code; allocations usa sales_document_id/allocated_amount; no guarda Collection POS original, tasa, recibido/base/no aplicado ni IDs POS. Exige monto aplicado igual cobrado. Es otro flujo | Nuevo respaldo operacional de Collection íntegra con allocations e IDs fuente. No adaptar cobro de ruta para simular original | C/E/P |
| Anticipos agenda / wallet | `wallet_deposit_amount` en summary y `WALLET_MOVEMENT_POSTED.payload.transaction`, L3969; `propertyManagementService.js` L160 lee depositPaid de actividad, no recibo original | Saldo/depósito de actividad no conserva asignaciones del cobro. Wallet vinculado a venta no demuestra canal completo de anticipos o abonos | Tipos separados ADVANCE/WALLET/COLLECTION con procedencia y relaciones; el hilo POS debe ratificar originales y cálculo, no sumar saldos como ingresos | C/O/P |
| Z y miembros | POST `/api/sync/z-reports` L7292; `deriveZReportEvents` L4064; `payload.report` + summary; [posZReportService.js](../../server/services/posZReportService.js) L443 reconoce event_id o summary.report_id | Summary proyecta montos/fechas, no crea listas. Report original disponible, no prueba membresía. Auditoría L478 consulta created_at por días con límite 5000; `applyCashClosePosted` L4517 usa ventanas y candidatos hasta 25000 (lanza error al alcanzar tope) | Nuevo manifiesto `{kind,id,revision}` por cierre + previousCloseId; legado UNKNOWN. `accounting_cash_close_event_id` L4452/4464 solo contribución contable | C/O |
| Fiscal/series | [posSequenceSync.js](../../server/services/posSequenceSync.js) L124/188/240/290; `erp_document_series.next_number`, `erp_fiscal_ranges.current_global`, `erp_terminal_fiscal_allocations.{reserved_start,reserved_end,next_number,last_issued_number,last_confirmed_number}` | Avance desde documentos que llegaron; compañía/sucursal y reserva importan. Lectura de maestros transforma estructura; estados fiscales posteriores no se garantizan por evento inicial | Lectura segura por reserva, no invocar funciones sync/backfill desde recuperación. Versionar respuestas fiscales posteriores; bloque perdido no reutilizable | C/E/P |
| Pedidos abiertos/mesas/splits/KDS | `/api/sync/collections/:collection/{full,delta,data,metadata}`, [syncMasterCollections.js](../../server/services/syncMasterCollections.js) L1056/1166 | `tables` y `rooms` = businessConfig; configuración no es ticket estacionado ni cuenta activa. No referencia a parkedTickets en backend auditado | Fuera de cobertura exacta actual; originales operacionales separados si se incorpora este alcance; no restaurar KDS desde mesas configuradas | C/P |

## Canales, identidad y estados existentes

**Implementados en código (no probados por HTTP contra producción en esta tarea):** recepción `/api/sync/transactions`, `/cash/movements`, `/z-reports`, `/inbox`, `/inbox/batch`; auditoría GET `/api/pos/z-reports` y `/:id`; POST `/:id/force-sync` existe y aplica/reintenta, **prohibido usar en recuperación**. Montaje [server/index.js](../../server/index.js) L194/209; [api/sync.js](../../api/sync.js) L164 delega rutas fuera de whitelist al router. Ni config-snapshots ni manifest de configuración de terminal son snapshots de operaciones. `posEventRecovery.js` selecciona documentos ERP para el aplicador por código/fecha/monto; no es restauración POS.

- **Directo:** eventId estable derivado de ID original + tipo (sin scope de tenant en esa semilla). IDs faltantes recurren a Date.now: no recuperan identidad original. Recepción individual L2548 preserva campos originales existentes y rellena contexto faltante. Puede reintentar aplicador al duplicar; no usar reenvío como lectura.
- **Batch:** `syncInboxBatch.js` exige token, flag `SYNC_BATCH_INBOX_ENABLED`, 50 eventos/25 transacciones/512 KiB. Acepta eventId UUID del emisor, no deriva todos los eventos financieros automáticamente. RPC `erp_sync_receive_inbox_batch` materializa recepción atómica y aplicación ocurre después por evento. Duplicados conservan transaction/report existentes, pero sobrescriben payload tenant/store/terminal/received_via; columnas conservan valores no nulos. La validación de conflicto RPC es de tenant, no revisión ni store/terminal. Misma identidad con payload distinto no equivale a nueva versión; una discrepancia columna/payload requiere SCOPE_UNRESOLVED. Definición real de RPC incluida en evidencia y coincide en esta lógica con migración `20260822171058_erp2b_receive_inbox_batch.sql`.
- **Genérico/legacy:** `/inbox` puede permitir compatibilidad sin token según política desplegada; no heredar ese modo en recovery. Fallback de tabla `sync_events` se usa solo si falta tabla ERP y devuelve APPLIED sin aplicador: fuente observada no incluye dicha tabla en public. `sync_inbox` sí existe y tiene event_version, pero **0 filas**, sin consumidor encontrado por búsqueda literal en repo. No asumir que event_version sea revisión del objeto POS.
- **LAN:** metadatos MASTER/SLAVE no demuestran broker ni respaldo. ERP ve lo que llega a estas rutas; no inspeccionamos POS ni red LAN. Cualquier adaptación LAN debe aportar originales/identidad de origen verificables, no atribuirlos al dispositivo relay. No hay contrato LAN exacto probado aquí.
- **Otros:** `UBER_EATS_MARKETPLACE` ocupa el inbox (ruta `server/routes/uberEats.js`); no incluirlo en conjunto de tablet por coincidencia de fecha. `SALE_CREATED`, `TRANSACTION_CREATED`, `INVOICE_AUDIT_RECORDED` observados no están en la normalización SALE/NC de L225. Necesitan adaptador explícito o original/status UNKNOWN; nunca reinterpretación automática como venta aplicada.
- **Unicidad real:** UNIQUE global event_id y parcial (tenant_id,event_id) coexisten. El global impide reutilización entre tenants; el parcial no la habilita. Batch produce `409 SYNC_BATCH_EVENT_SCOPE_CONFLICT`; individual puede terminar en error SQL sin ese envelope. No cambiar índices aquí. Nuevos IDs de revisión se diseñan por separado del eventId financiero, y mismo ID/revisión con distinto hash será 409.

Estados en [posSyncEventOutcome.js](../../server/services/posSyncEventOutcome.js): RECEIVED/STAGED/APPLY_PENDING son pendientes, PROCESSING no es aplicado, FAILED puede tener efectos parciales, DUPLICATE solo no prueba nada. `applySyncInboxEventById` L4709 reclama estado y ejecuta varias escrituras; solo al final guarda APPLIED y application. Fallo intermedio no asegura rollback comercial. Incluso la rama ALREADY_APPLIED puede reconciliar cupones. El restaurador no debe llamar **ningún** aplicador. `accounting_deferred_to_cash_close`/`accounting_deferred_to_closed_period` (L1135+) separan aplicación comercial de contabilidad final.

## Frontera y cobertura revisadas

No se encontró sesión durable de caja operacional en rutas/servicios ni catálogo de tablas public consultado. `data_sessions` es motor import/export (`dataExchangeSessionEngine.js` L42–49); `erp_pos_diagnostic_sessions` expira (máximo 24h, `posDiagnosticTrackingService.js` L89); ninguna es jornada. No se prueba ausencia universal de toda integración externa.

Se propone **EXPLICIT_OPEN_SET**: POS persiste openSetId antes del primer documento/abono/movimiento, asigna revisiones durables y conserva pertenencia hasta cierre explícito. No particionar por día, timezone, recepción ni reloj de la tablet. Cada Z persiste su propio ID, eventId, previousCloseId, IDs+revisiones de miembros y configuración/declaración utilizadas. El paso local que produce Z y su manifiesto debe ser atómico en POS; el ERP reconoce identidad de cierre aunque esté RECEIVED o FAILED. Un Z recibido con ACK perdido se devuelve como `CLOSE_REFERENCE`, `observedCloseIds` y `closeAcknowledgementRequired=true`; jamás crear otro para reemplazarlo. Si miembros no se conocen, UNKNOWN y activación para cierre bloqueada.

Legado: boundary.kind=LEGACY_UNKNOWN, openSetId/previousCloseId nulos si no demostrados, membership UNKNOWN. Se puede ofrecer copia de originales conocidos del alcance comprobado como candidatos, con todos los cierres conocidos y referencias necesarias, nunca llamar OPEN a «sin zReportId». Un período técnico de retención puede acotar candidatos solo si se declara como limitación con cantidades desconocidas. No limitar silenciosamente por fechas ni por los topes de auditoría.

Cobertura:

- `downloadIntegrity`: EXPECTED en manifiesto; POS pasa a VERIFIED solo tras hashes/lista/páginas. No modificar manifiesto para registrar verificación local.
- `deviceCoverage`: UNKNOWN, PARTIAL o COMPLETE_AT_CHECKPOINT; esta última prueba únicamente prefijo confirmado de una época, no toda actividad posterior.
- `membershipCoverage`: EXACT/PARTIAL/UNKNOWN independiente de recepción y aplicación.
- `knownMissing`: IDs/revisiones conocidos y `unknownCount=true` cuando no se puede contar; no usar cero para desconocido. `unknownTailPossible=true` por defecto tras pérdida total.
- `exactZEligible=true` exige conjunto sellado exhaustivo, originales/revisiones/relaciones completos, regla de cálculo/configuración/declaración conocidas, sin cola desconocida, cobertura exacta y política de series segura. APPLIED no es requisito matemático: pendientes se copian con incidencia; autorización de emitir/cerrar se decide aparte. En legado o pérdida sin prueba del final: false aunque cuadren todos los conteos.
- Checkpoint nuevo: `{storageEpoch, durableSequence, contiguousWatermark, highestReceived, gaps, lastCompleteCheckpoint, sealedThrough}`. Incluir altas, mutaciones, fondos, abonos y cierres, no solo ventas. Dos eventos contables derivados de una operación no son dos posiciones de log operacional. `globalSequence` recibido no demuestra este protocolo. Pérdida de cola posterior al watermark sigue siendo posible.

## Contrato HTTP propuesto

[contract.schema.json](contract.schema.json) es JSON Schema 2020-12 para envelopes propuestos, no implementación. `$defs` contiene Request, Manifest, Record, Page, Status, ReceiptRequest y Error. Descarga, status y ACK técnico nunca autorizan un nuevo cierre: Manifest y Status exigen `closeAuthorization=NOT_GRANTED`. `exactZEligible` describe reproducibilidad, no permiso de cerrar. ActivationRequest/Response se retiraron de este schema y están exclusivamente en [closure-protocol.schema.json](closure-protocol.schema.json), propuesta separada sin acuerdo. `original` queda como objeto extensible para preservar todos los campos: **falta ratificar esquemas nativos POS por versión; consultar `original-profiles.json`, `original-profiles.schema.json` y `original-validation-results.json`**, no se certifica completitud operacional solo validando el envelope.

Todas las rutas siguientes son **NUEVAS, NO IMPLEMENTADAS / NO PROBADAS POR HTTP**:

| Método/ruta bajo `/api/sync/recovery` | Semántica y respuesta |
|---|---|
| POST `/snapshots` | Idempotency-Key obligatorio; body Request. 201 nuevo / 200 repetido; Location y ETag. Captura consistente sin aplicar eventos. Mismo body canónico y alcance/credencial lógica → mismo recurso; body diferente → 409. Concurrencia misma clave produce uno solo. Crear snapshot sí escribe artefactos técnicos futuros, no negocio |
| GET `/snapshots/:snapshotId` | 200 Manifest inmutable, ETag fuerte; no recalcular con datos actuales. Autorización fresca antes de cualquier respuesta/cache |
| GET `/snapshots/:snapshotId/records?cursor=...&limit=200` | 200 Page estable, orden `(kind,originalId,originalRevision,role)` por ordinal persistido. Default y máximo 200; máximo propuesto 2 MiB UTF-8 por body completo. Validar 1..200. Menos registros por bytes permite nextCursor; final solo si ordinal/count/hash coinciden. Nunca devolver página vacía con cursor siguiente. Registro individual excesivo → 422 RECORD_TOO_LARGE en creación, no omitirlo |
| GET `/snapshots/:snapshotId/status` | 200 Status actual, no parchea snapshot ni contiene activationAllowed. Cambios en originals/membership/closes/scope/series exigen revisión o nueva captura; cambios solo application se muestran por sourceEventId, sin reimportar pagos. no-store |
| POST `/snapshots/:snapshotId/receipts` | Opcional, Idempotency-Key; 200 ACK de importación, hashes/counts/versiones verificados. No elimina originales, no cambia inbox, no habilita cierre |

Propuesta TTL: snapshots 24h desde captura, idempotency/recibos/tombstone de expiración 7 días. Una clave cuyo snapshot expiró devuelve 410 durante esos 7 días; usar clave nueva para nueva captura. Después vence garantía de deduplicación de esa clave. Originales: retención durable independiente, sin purga por ACK ni por TTL del snapshot; sin GC automático hasta acordar política de archivo y retención con negocio. Estos plazos requieren validación de volumen/operación.

Cursor opaco autenticado enlaza snapshotId, hash de alcance histórico, contractVersion, ordinal siguiente, límite efectivo de registros/bytes y expiresAt. Repetir cursor+limit devuelve mismos bytes. Cambiar limit con cursor → 400; ajeno → 404 sin información. Un cursor no es credencial. El manifesto integra inventario ordenado completo `{ordinal,kind,originalId,originalRevision,role,hash}`; para v1 se propone máximo de manifiesto 8 MiB: si excede, 422 MANIFEST_TOO_LARGE, sin truncar. Escalar a índice paginado requerirá nueva revisión del contrato, no truncado oculto.

### Autenticación y alcance

Reutilizar `resolveAuthorizedTerminal` L2669, `assertCanonicalDeviceAuthorization` L1659 y takeover existente L6042 (RPC con expected previous device). En recuperación exigir **X-Sync-Token + X-Device-Id**; no usar Bearer de setup como sustituto ni modo legacy sin token. Diferencia explícita: helper actual permite deviceId ausente por defecto; llamar con `allowMissingDeviceId:false` y controlar presencia en headers para nueva ruta. La resolución actual puede devolver 404 si no encuentra terminal antes de validar token; recovery normaliza auth inválida a 401.

La terminal se resuelve por token, relee canónica fresca y scope autorizado de fuentes confiables; hints del body no son autoridad (Request rechaza campos extra). Scope histórico incluye tenant/company/store/terminal y procedencia por registro. `resolvePosEventScope` L72 puede completar compañía desde tienda **actual**: no sirve como prueba histórica cuando se movió la terminal. Un alias solo se acepta con evidencia persistida del vínculo a ese alcance; alias de dispositivo sustituido es dato histórico, nunca credencial vigente. Conflicto columna/payload o compañía histórica imposible de probar → 409 SCOPE_UNRESOLVED; no buscar empresa arbitraria ni mezclar datos. Referencias cerradas permanecen dentro de alcance comprobado; no revelar IDs externos.

Cada GET/POST de descarga/importación (incluidos reintentos, páginas, status y receipt) revisa token, revocaciones, dispositivo canónico, activo/licencia y propiedad de snapshot. Dispositivo viejo → 403 DEVICE_SUPERSEDED; inactivo → 403 LICENSE_EXCEEDED_INACTIVE. En nueva API se normaliza envelope conservando códigos, sin cambiar respuestas legacy. El middleware existente escribe intentos de auth denegada; se acepta auditoría **técnica** futura, jamás efecto financiero. Evitar caché de contexto como autoridad de compañía y revalidar contra takeover al cerrar la transacción; una respuesta ya enviada antes del takeover no se puede retirar.

### Consistencia y carrera final

`created_at <= capturedAt` no congela payload ni application. Propuesta mínima: materialización de registros, miembros, referencias, series y manifiesto en **una transacción REPEATABLE READ**; `cut.revision` es revisión operacional durable por alcance, no timestamp ni número de venta. Si crece, historial append-only puede sustituir copia de originales, pero estados también deben congelarse. Varias llamadas REST independientes no forman esa transacción. Referencia de semántica: [PostgreSQL isolation](https://www.postgresql.org/docs/17/transaction-iso.html).

El protocolo que puede habilitar un nuevo cierre está separado en [closure-protocol.md](closure-protocol.md), con [schema candidato](closure-protocol.schema.json) y [fixtures candidatos](closure-protocol.fixtures.json). No es una etapa implícita de la importación ni una autorización proporcionada por status/receipt. Todo legacy sigue UNKNOWN y sin cierre exacto habilitado.

### Hashes, registros y totales

SHA-256 hexadecimal de bytes UTF-8 con [JCS RFC 8785](https://www.rfc-editor.org/rfc/rfc8785). Ordenar propiedades según JCS, mantener orden de arrays y Unicode sin normalizar, rechazar claves duplicadas/NaN/Infinity y números que no puedan representarse sin pérdida. Nuevos metadatos monetarios usan strings decimales; originales conservan tipos recibidos, no convertir en silencio. JSONB ya perdió whitespace/orden de claves/representación numérica original: hash legacy prueba objeto recibido almacenado, no bytes originales del POS. Si hubo pérdida numérica irreversible → incidencia/422, no fabricar valor.

`Record.hash` cubre el registro completo excepto su campo hash (incluye receipt/application **al corte**, original, relaciones y scope). `recordsHash` cubre el array ordenado de entradas de inventario. `pageHash` cubre Page sin pageHash; `Manifest.etag` = hash de Manifest sin etag, HTTP ETag entre comillas. No ciclos de hashes. Status tiene su propio estado actual y no afecta hashes congelados. Los bytes de ejemplo y sus hashes están en fixtures; no certifican implementación JCS general.

Record distingue `role=MEMBER|CLOSED_REFERENCE|CLOSE_REFERENCE|EVIDENCE`, `membership=OPEN|CLOSED|UNKNOWN` y revision `UNKNOWN` si no comprobada. Un Z legado observado puede ser CLOSE_REFERENCE con membership UNKNOWN. `originalSchemaVersion=UNKNOWN` también impide asegurar semántica plena. Pagos embebidos se vinculan por paymentId y sourceEventIds: un PAYMENT_REFERENCE con role EVIDENCE no se suma como otro cobro. Las relaciones especifican kind/id/revision, tipo y readOnly. Dependencia cerrada de abono o devolución se incluye como referencia read-only, excluida de totales del conjunto; faltante declara incidencia, no religa a una factura parecida.

Receipt describe recepción por evento/fuente; application conserva estado de inbox, efectos document/inventory/debt/wallet/accounting/fiscal, evidencia e IDs ERP de conciliación. Ausencia de evidencia → UNKNOWN, no NOT_APPLIED. Efectos parciales posibles aun FAILED; contabilidad DEFERRED aun APPLIED. `retryable` describe reintento ERP separado, jamás permiso de reenviar desde importador. No publicar last_error bruto si contiene datos de otro alcance; error normalizado.

Totales son buckets por measure, moneda, baseCurrency y method/methodId histórico: recibido original/base, aplicado base, cambio original/base, IN/OUT, ventas, devoluciones, descuentos, impuestos, abonos, anticipos y no aplicado. Sin tasa histórica: cantidad base null, completeness UNKNOWN. Valores de diferentes monedas no se suman sin conversión histórica; referencias y PAYMENT_REFERENCE se excluyen. Conservar también cálculo/configuración/declaración del Z fuente. No inferir método actual del catálogo.

Fixture F01: venta 550 DOP, recibe 10 USD a 60, cambio 50 DOP: recibido base 600, aplicado 550, cambio base 50; efectivo físico **USD +10, DOP -50**, equivalente neto convertido de 550 DOP antes de fondo, sin duplicar PAYMENT_POSTED. **550 DOP no son billetes DOP físicos: el cashExpected real comunicado por POS es {USD:10,DOP:-50}**. El movimiento físico es USD +10 / DOP −50; el campo `CONVERTED_CASH_NET_BASE` expresa la conversión histórica y `posCashExpected` contiene el resultado comunicado por el hilo POS para el commit `5993b1fed18c230dde89734e91fa94e0a95ce2bc`; el ERP no ejecutó su motor. `PHYSICAL_CASH_NET` exige baseCurrencyCode=null. Fixture F02: solo abono 100 DOP, asignado 80, no aplicado 20. Según requisito POS, stats incluye abono, cashExpected legacy excluye collections (0 sin movimientos), y openedAt usa la hora actual al crear cierre cuando no hay ventas ni movimientos, no la fecha del abono. El mapa real cashExpected es `{}` y la UI usa cero por defecto para monedas ausentes. El resultado de una fórmula corregida sería 100, pero **no cambiarla como parte de restauración**. Ambas expectativas están separadas y el hilo POS ya comparó estos fixtures con su código; no se autoriza corregir la omisión de abonos. F04 devuelve `{DOP:1050}` con los miembros actuales y mantiene la devolución NO VALIDADA para recuperación.

### Series y errores

Por misma compañía/serie/reserva: candidato `max(localNext, remoteNext, usedKnown+1)` usando enteros exactos (strings en JSON). No llamar `syncOperationalSeriesFromPosEvent` ni `backfillPosSequencesFromHistory` al leer; contienen UPDATE. Si último uso offline es desconocido, no tomar el next remoto como libre. Propuesta: apartar reserva perdida completa y solicitar bloque nuevo por mecanismo fiscal vigente fuera del restaurador; lectura devuelve UNSAFE/BLOCK_REPLACEMENT_REQUIRED hasta confirmar asignación no solapada. Para serie interna no reservada sin límite seguro: bloqueo de nueva numeración hasta asignar serie/bloque seguro, no inventar salto. No bajar contadores, no consumir un número por importar, no emitir comprobante. Acordar procedimiento concreto de retiro/avance y probar concurrencia antes de implementar; la existencia de columnas de reserva no acredita que ese procedimiento esté listo.

| HTTP | Códigos propuestos / conducta |
|---|---|
| 400 | CONTRACT_INVALID, CURSOR_INVALID, LIMIT_INVALID, DEVICE_ID_REQUIRED; corregir solicitud |
| 401 | SYNC_AUTH_REQUIRED / SYNC_AUTH_INVALID; no revelar existencia de terminal |
| 403 | DEVICE_SUPERSEDED, LICENSE_EXCEEDED_INACTIVE, SCOPE_FORBIDDEN |
| 404 | SNAPSHOT_NOT_FOUND para inexistente o ajeno, mismo envelope |
| 409 | CUT_CHANGED, ORIGINAL_ID_CONFLICT, IDEMPOTENCY_KEY_REUSED, SCOPE_UNRESOLVED, MEMBERSHIP_UNRESOLVED |
| 410 | SNAPSHOT_EXPIRED; nueva captura/clave, no mezclar páginas |
| 422 | ORIGINAL_UNRECOVERABLE, RECORD_TOO_LARGE, MANIFEST_TOO_LARGE, SERIES_UNSAFE (activación); un fallo de registro con impacto en importación exige corregir captura, no saltarlo |
| 429 / 503 | RATE_LIMITED / RECOVERY_UNAVAILABLE, retryable=true, Retry-After obligatorio |

Envelope nuevo `{error:{code,message,retryable,details},requestId}`; detalles siempre scope-safe. 409 CUT_CHANGED indica recapturar (retryable=false para misma captura), no bucle ciego. Cobertura parcial conocida permite 200 + exactZEligible=false; transporte correcto no equivale a exactitud. Snapshot con series desconocidas sí se puede descargar con UNSAFE; 422 se exige al intentar activar para cierre/emisión.

## Cambios mínimos posteriores a validación

1. Modelo durable append-only de originales/revisiones y contexto histórico; Collection/allocations, mutaciones/VOID, estados fiscales, anticipos y membresía. Canal de respaldo de metadata separado de eventos financieros. Mismo ID+revisión+hash idempotente, hash distinto 409; nunca usar eventId de aplicación para actualizar original.
2. Manifiesto de cierre persistido con miembros/versiones y previousCloseId; distinguir cierre recibido de aplicado y preservar ACK perdido. No «completar» legado con ventanas exactas.
3. Snapshots materializados + lectura autenticada + cursor + TTL + coverage; dependencia cerrada read-only; cero llamadas comerciales. Acceso a tablas técnicas solo por servidor autorizado, sin exponer copias por Data API pública.
4. Log/checkpoint por storageEpoch y secuencia durable con gaps; escritura local atómica y sync background fuera del camino crítico del cobro; retransmisión técnica no aplica negocio.
5. Originales con retención independiente de diagnósticos y ACK. Guard por revisión/activación para canales involucrados y validación final de cierre, reusando exclusión de dispositivo vigente.
6. Conciliación de reservas mediante mecanismo vigente separado y seguro; habilitar por flag en terminales validadas. No activar para legado inseguro.

## Fixtures y pruebas propuestas

[fixtures.json](fixtures.json) contiene datos artificiales, resultados esperados, envelopes completos y matriz de casos. Validar schema/hashes/aritmética de archivos no prueba endpoints ni equivalencia con el POS real. Implementación posterior deberá correr en fixtures/bases aisladas y usar el cálculo POS de referencia con misma configuración/declaración.

`fixtures.json` incluye cuatro paquetes de descarga/importación: F01 moneda/cambio legado, F02 solo abonos y referencia cerrada, F03 ACK Z perdido, F04 canales/revisiones/fallo parcial. F05 y los ejemplos de activación se movieron a `closure-protocol.fixtures.json`; son candidatos sin acuerdo y sin habilitación de cierre. Todos los paquetes publicados mantienen `exactZEligible=false` y `closeAuthorization=NOT_GRANTED`. `counts.byEventState` cuenta sourceEventId únicos; `counts.byKind` cuenta registros, incluidas referencias. No confundir ambas unidades. [fixture-record.canonical.json](fixture-record.canonical.json) conserva bytes sin salto final para contrastar hash; `canonicalizationVectors` incluye UTF-8/orden UTF-16 y un exponente numérico.

| Caso | Resultado obligatorio |
|---|---|
| Z equivalente | Mismos IDs, revisiones, declaración, descuentos/impuestos y cálculo versionado → mismo Z; registrar diferencias de versión, no recalcular con catálogo actual |
| Corte de red/repetición/reinicio | Import staging transaccional; repetir páginas/activation sin duplicar; contador y tablas comerciales idénticos antes/después |
| ACK Z perdido | Conservar report.id/eventId y estado RECEIVED/FAILED; no nuevo cierre ni reenvío automático |
| Pendiente/FAILED parcial/APPLIED deferred | Copia con incidencia, UNKNOWN por efectos no demostrados; actualización de status no altera hashes |
| Cola nunca enviada/pérdida total | unknownTailPossible=true, knownMissing.unknownCount=true, exactZEligible=false aun conteos iguales |
| USD/cambio/crédito | F01 más ventas a crédito: recibido ≠ aplicado ≠ deuda; no duplicar pagos ni convertir con tasa actual |
| NC/VOID/abono/anticipo/wallet | Revisiones explícitas, asignaciones por ID, referencias cerradas read-only; ningún efecto comercial nuevo |
| Tenant/store/alias/takeover | Token ajeno no accede ni por cursor; transferencia empresa irresuelta 409; takeover entre páginas rechaza siguiente petición/activación |
| Medianoche/múltiples días/reloj atrasado/recepción tardía | Misma pertenencia por openSetId y revisión; tiempo nunca añade/quita miembros; recepción posterior cambia cut |
| Series/reserva perdida | No bajar next; no reutilizar intervalo desconocido; UNSAFE bloquea activación fiscal, no lectura de copia |
| Corrupción/truncado/cursor ajeno | Falla de hash/lista/count o dependencia impide activar, ninguna importación parcial silenciosa |
| Carrera final | Escribir cierre/revisión después de GET status y antes de activation/aceptación Z → 409; probar bloqueos en dos conexiones reales aisladas |
| Solo abonos | F02: openedAt y cashExpected requieren decisión POS; no inventar venta/fondo de apertura |

Decisiones críticas pendientes: esquemas originales y revisiones POS por tipo; significado/cobertura del checkpoint sellado; comparación ejecutable del cálculo legacy de solo abonos y openedAt (hallazgos ya ratificados); protocolo de activación y guard compartido de cierre; retiro seguro de reservas perdidas; retención/volumen/límites; clasificación de alias/cambio de compañía y canales externos. Hasta resolverlas, **contrato propuesto verificable por estructura y fixtures, pero no listo para POS**. Esperar validación antes de endpoints.

## Validación realizada en esta entrega

- `node docs/pos-pending-day-recovery/verify-fixtures.mjs`: 4 paquetes de descarga/importación y 1 candidato de cierre separado, 3 vectores de bytes, efectivo físico vs equivalente convertido, legacy UNKNOWN, ausencia de permisos de cierre y 5 negativos, PASS.
- `python docs/pos-pending-day-recovery/verify-schema.py` con `jsonschema==4.25.1` en venv temporal: tres schemas 2020-12 separados, 42 envelopes, 10 negativos y 15 evaluaciones de originales (ninguna certificada), PASS. Instalar esa dependencia en entorno aislado para reproducir; no se añadió a dependencias del ERP.
- `npx eslint docs/pos-pending-day-recovery/verify-fixtures.mjs`: PASS. Enlaces locales y `git diff --check`: PASS.
- Tests existentes `posSyncEventOutcome.test.js`, `posSaleEventContract.test.js`, `syncInboxBatch.test.js`, `terminalDeviceAuthorization.test.js`: **32 PASS**, pruebas locales puras; no llamadas HTTP/DB.
- `npm ci --no-audit --no-fund` con lockfile existente, después `npm run build`: PASS (TypeScript + Vite + PWA; aviso de chunks grandes). El primer intento con dependencias compartidas incompletas falló por vite-plugin-pwa; el worktree ahora usa instalación propia. Ningún cambio al lockfile ni aplicación.
- Smoke de artefactos = verificadores anteriores. **No** se probó recuperación por HTTP, carreras transaccionales, restauración POS ni equivalencia del cálculo POS real; las rutas nuevas no existen y la matriz de integración sigue siendo propuesta.

## Artefactos para contrastar con POS

El documento no sustituye la comparación de estos archivos:

- [contract.schema.json](contract.schema.json): descarga/importación, sin ActivationRequest/Response.
- [fixtures.json](fixtures.json): F01–F04, resultados esperados y casos offline.
- [verify-fixtures.mjs](verify-fixtures.mjs): integridad, relaciones, unidades monetarias y negativos, solo Node estándar.
- [verify-schema.py](verify-schema.py): envelopes, dos contratos separados y negativos; requiere jsonschema 4.25.1.
- [closure-protocol.schema.json](closure-protocol.schema.json) y [closure-protocol.fixtures.json](closure-protocol.fixtures.json): candidatos separados, SIN ACUERDO.

Para ejecutar fuera del ERP, descomprimir el paquete conservando `docs/pos-pending-day-recovery/` y ejecutar desde la raíz extraída:

```sh
node docs/pos-pending-day-recovery/verify-fixtures.mjs
python3 -m venv .venv
.venv/bin/python -m pip install jsonschema==4.25.1
.venv/bin/python docs/pos-pending-day-recovery/verify-schema.py
```

No requiere variables de entorno ERP, credenciales, acceso a Supabase ni código del POS. La instalación de jsonschema requiere acceso al registro de paquetes; las verificaciones posteriores son offline. El paquete incluye los tres schemas, perfiles candidatos, evaluaciones de originales, ambos archivos de fixtures y los bytes canónicos requeridos. Los resultados F01/F02/F04 comunicados por POS están registrados con SHA. R4 incorpora definiciones nativas y ejemplos STORE_CREDIT/CARD; siguen pendientes acuerdo de versiones/perfiles completos y reembolso CASH/multimoneda; el verificador actual no certifica equivalencia de restauración ni ejecuta el motor POS.

### Verificación adicional R4

Tras instalar jsonschema como se indica arriba:

```sh
python docs/pos-pending-day-recovery/verify-r4.py
```

Comprueba checksums del ZIP POS archivado, originales sin alteraciones, diferencias direct/batch, perfiles corregidos, límites de timestamps y casos de protocolo. No ejecutar los scripts POS archivados como parte de esta verificación: requieren su fuente y no forman parte del verificador ERP.
