# Protocolo de nuevo cierre recuperado — separado, SIN ACUERDO

> Revisión posterior R4: [invariantes conjuntas y una revisión por operación](r4-invariants-response.md). Esta precisión sustituye la unicidad por terna y las verificaciones aisladas del candidato; sigue siendo propuesta UNAGREED.

> R4 precisa y sustituye los candidatos de nombres/hash/sello de abajo: [respuesta, puntos8–11](response-r4.md). `$defs/CloseManifest`, `CheckpointProposal` y `CloseAcceptanceCandidate` son formas UNAGREED. `closeEventId`, `revision` y `originalContentHash` reemplazan los nombres ambiguos del borrador R3. Sello propuesto OPEN_SET; su ratificación está pendiente.

Este protocolo no forma parte de `contract.schema.json` (descarga/importación). Un ACK de importación, igualdad de hashes o una respuesta de status no habilita un nuevo Z. No hay endpoints implementados ni se cambia el cálculo actual del POS.

Antes de implementar deben acordarse cuatro artefactos:

| Acuerdo | Contenido requerido | Estado |
|---|---|---|
| Original por tipo y versión | Sale/NC/VOID, líneas, pagos, movimientos, Collection/allocations, anticipos/wallet, referencias y estados fiscales; comparar campos, tipos numéricos, opcionales y relaciones con POS real | PENDIENTE |
| Manifiesto persistido de cierre | ID/eventId original, openSetId, previousCloseId, miembros con kind/ID/revisión, declaración y configuración/cálculo históricos; atomicidad local de Z + miembros | PENDIENTE |
| Checkpoint sellado | storageEpoch, secuencia durable, watermark contiguo, gaps, prueba de prefijo completo y semántica de sello final; no confundir prefijo confirmado con ausencia de cola posterior | PENDIENTE |
| Aceptación concurrente de cierre | Punto transaccional de compare-and-swap, revisiones afectadas, takeover vigente, todos los productores participantes, crash/retry y cierre provisional offline | PENDIENTE |

`closure-protocol.schema.json` conserva formas **candidatas** ActivationRequest/Response; el nombre de ruta `POST /api/sync/recovery/snapshots/:snapshotId/activations` también es candidato. No se invoca desde descarga/importación. Una ActivationResponse candidata solo sería un paso técnico: seguiría exigiendo comparación atómica al aceptar el nuevo cierre, cuya forma definitiva requiere el acuerdo anterior. No hay contrato final de CloseRequest aprobado.

`closure-protocol.fixtures.json` declara `agreementStatus=UNAGREED` y contiene casos de carrera/reserva y el antiguo F05 como hipótesis explícita. Incluso F05 ahora tiene `exactZEligible=false` y `closeAuthorization=NOT_GRANTED`: los esquemas/cálculos reales no están acordados. La respuesta candidata de activación ilustra una forma futura; no es resultado obtenido ni autorización vigente.

Legacy: mantener membership/revision UNKNOWN, `exactZEligible=false`; ningún permiso de cierre puede derivarse de números convertidos ni conteos coincidentes. Un Z ya recibido se reconoce con su ID/eventId original, incluso RECEIVED/FAILED, sin crear otro ni reenvío automático.

## Diseño transaccional para discusión

**GET status no cierra la carrera.** Propuesta para validar, todavía sin código:

1. Importar en staging local (transacción/journal recuperable), comprobar páginas/hash/relaciones, sin cola financiera automática ni activar selectores de cierre.
2. POST activations compara cut.revision, membershipRevision, closeRevision, seriesRevision, scopeRevision y token/dispositivo vigente bajo bloqueo de la misma terminal y de la fila de control de recovery. Persiste activationId idempotente, epoch operativo y digest del inventario. Revisa cobertura/series; legado devuelve 409 MEMBERSHIP_UNRESOLVED o 422 SERIES_UNSAFE. No actualiza venta, contador fiscal ni cierre.
3. **Todas** las futuras escrituras de originales/pertenencia/cierres que afecten el alcance deben participar del mismo control transaccional; takeover mantiene su mecanismo actual y revoca activación por cambio de credencial. Recepción tardía del dispositivo sustituido queda excluida por auth existente; cambios administrativos y otros canales relevantes invalidan la revisión. El guard debe incorporarse en canales directo, batch, genérico y cualquier productor equivalente; no basta agregarlo al nuevo endpoint.
4. POS activa localmente con journal durable y activationId. Crash antes/después se resuelve repitiendo misma activación; respuesta idéntica solo después de comprobar auth fresca. Si hay cambio de revisión devuelve 409, no autoriza snapshot viejo. Lectura local puede mostrarse; **confirmación de nuevo Z recuperado** lleva activationId, expected revisions, ID/eventId original y manifiesto, y vuelve a comparar atómicamente al recibir cierre. Si cambió el corte, rechaza antes de aplicación. Cierre ya recibido se reconoce por sus IDs incluso fallido; no se sustituye.
5. La importación local y ERP no pueden hacerse una sola transacción por HTTP. Por eso la garantía se fija en el punto de aceptación atómica del cierre, no en un GET previo. Un Z recuperado offline permanece provisional, no puede prometer aceptación exacta final sin esta comprobación. Venta local normal sigue sin depender de red; sincronización del log en background. Cualquier exigencia de aceptar definitivamente el cierre recuperado offline necesita decisión adicional: no se promete aquí.

Esta extensión es mínima para evitar la carrera, pero requiere acuerdo POS/ERP y guard compartido aún inexistente. No rediseña pairing/takeover. Snapshot no es un bloqueo de la venta normal ni habilita emisión; los controles de recuperación son por terminal afectada y fase de reconciliación.


## Comparación pendiente con POS

Los verificadores compartidos comprueban estructura de envelopes, integridad de los archivos y aritmética explícita del fixture. No ejecutan los tipos/selectores/cálculos POS ni implementan el protocolo distribuido. Ratificar cada original y añadir resultados exportados del cálculo real POS antes de considerar equivalencia. Reproducir la fórmula actual y corregir abonos/openedAt siguen siendo tareas separadas.

## Precisiones R3 para acordar

El hilo POS ya comunicó resultados reales F01/F02/F04 para `5993b1fed18c230dde89734e91fa94e0a95ce2bc`; ver [review-r3.md](review-r3.md). La representación del reembolso de F04 sigue sin validar. No inferir un Z aceptable a partir de esos totales.

**Manifiesto candidato:** `{closeId,eventId,originalRevision,openSetId,previousCloseId,members:[{kind,originalId,originalRevision,hash}],calculationVersion,configurationHash,declarationHash,storageEpoch,sealedThrough}`. Referencias cerradas se etiquetan aparte y no forman parte de los miembros abiertos. Hashes de configuración/declaración requieren sus valores históricos. Misma identidad/revisión con otro hash es conflicto, no nueva versión silenciosa. Esta estructura no reemplaza el ZReport original ni es un endpoint implementado.

**Conjunto abierto:** persistir openSetId antes del primer miembro y cada mutación; atraviesa medianoche/días sin cerrar. previousCloseId refiere a cierre explícito, no máximo por fecha. Unknown en legacy no se completa con rangos temporales. Sello de prefijo `(epoch,through,watermark,gaps)` prueba solo ese prefijo. Un sello final necesita declaración durable de fin de escritura de esa época, todos sus registros y mecanismo acordado que evite extensión; takeover existente excluye el dispositivo anterior pero no prueba ausencia de cola nunca subida. Sin prueba del final: unknownTailPossible=true y no cierre exacto.

**Productores que deben participar del guard común propuesto:** recepción /transactions, /cash/movements, /z-reports, /inbox, RPC de /inbox/batch; nuevo journal de originales/mutaciones/Collection/fiscal; cambios administrativos de alcance/alias y reservas; productor marketplace si participa del mismo alcance; reintentos/backfills que puedan alterar contenido o pertenencia. Si un canal legacy no puede participar, se declara incompatible con cierre exacto. Cambios exclusivos de application se consultan por status y deben reevaluarse si son precondición del cierre, sin volver a importar/cobrar. Takeover mantiene su mecanismo actual; se revalida su estado bajo la exclusión existente, sin otro pairing.

**Punto de aceptación candidato:** transacción que bloquea control del alcance y terminal autorizada, comprueba identidad canónica fresca, expected revisions y manifiesto, y persiste idempotentemente la recepción del Z. Orden para reintento: autenticar primero; si mismo closeId/eventId y hash ya existe, devolver recepción original aun RECEIVED/FAILED sin nueva aplicación; si otro hash, 409 ORIGINAL_ID_CONFLICT. Si es cierre nuevo y revisión cambió tras descarga/status/activación, 409 CUT_CHANGED antes de aceptarlo. Todos los escritores relevantes deben compartir guard/revisión. La aplicación comercial posterior pertenece al flujo normal ERP, nunca al importador.

**Offline y series:** un cierre recuperado offline solo puede ser provisional hasta aceptación remota; no prometer atomicidad entre DB local y ERP. Nueva descarga tras conflicto no mezcla páginas y mantiene IDs de cierre ya recibido. Importar no consume serie ni emite fiscalmente. Reserva perdida no reutilizable: bloquear/reasignar por mecanismo vigente no solapado, con prueba de retiro/avance; si no hay límite seguro no elegir un next arbitrario. `max(localNext,remoteNext,usedKnown+1)` solo dentro de la misma reserva segura, no resuelve uso offline desconocido.
