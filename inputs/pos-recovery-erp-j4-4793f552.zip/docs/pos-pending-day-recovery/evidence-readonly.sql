WITH shapes AS (
 SELECT event_type,status::text,count(*) AS n,
 count(*) FILTER (WHERE jsonb_typeof(payload->'transaction')='object') AS transaction_objects,
 count(*) FILTER (WHERE jsonb_typeof(payload#>'{transaction,items}')='array' AND payload#>'{transaction,items}'<>'[]'::jsonb) AS nonempty_items,
 count(*) FILTER (WHERE jsonb_typeof(payload#>'{transaction,payments}')='array') AS payment_arrays,
 count(*) FILTER (WHERE nullif(payload#>>'{transaction,zReportId}','') IS NOT NULL) AS transaction_zreportid,
 count(*) FILTER (WHERE payload#>'{report,transactionIds}' IS NOT NULL) AS z_transactionids_key,
 count(*) FILTER (WHERE payload#>'{report,collectionIds}' IS NOT NULL) AS z_collectionids_key,
 count(*) FILTER (WHERE payload#>'{report,cashMovementDetails}' IS NOT NULL) AS cashdetails_key,
 count(*) FILTER (WHERE jsonb_typeof(payload#>'{report,cashMovementDetails}')='array' AND payload#>'{report,cashMovementDetails}'<>'[]'::jsonb) AS cashdetails_nonempty
 FROM public.erp_sync_inbox GROUP BY event_type,status
), paths AS (
 SELECT event_type,'root' AS location,k AS key,v AS value FROM public.erp_sync_inbox
 CROSS JOIN LATERAL jsonb_each(CASE WHEN jsonb_typeof(payload)='object' THEN payload ELSE '{}'::jsonb END) x(k,v)
 UNION ALL
 SELECT event_type,child,k,v FROM public.erp_sync_inbox CROSS JOIN (VALUES('summary'),('transaction'),('report'),('movement')) c(child)
 CROSS JOIN LATERAL jsonb_each(CASE WHEN jsonb_typeof(payload->child)='object' THEN payload->child ELSE '{}'::jsonb END) x(k,v)
), aliases AS (
 SELECT event_type,location,key,jsonb_typeof(value) AS value_type,count(*) AS n,
 count(*) FILTER (WHERE value NOT IN ('null'::jsonb,'[]'::jsonb,'{}'::jsonb,'""'::jsonb)) AS nonempty
 FROM paths WHERE key ~* '(z.?report|close|session|member|transaction.?ids|collection|allocation|open.?set|revision|sequence|cashMovementDetails)'
 GROUP BY event_type,location,key,jsonb_typeof(value)
), channels AS (
 SELECT event_type,coalesce(payload->>'received_via','UNKNOWN') AS received_via,count(*) AS n
 FROM public.erp_sync_inbox GROUP BY event_type,payload->>'received_via'
)
SELECT current_timestamp AS observed_at,version() AS database_version,
 (SELECT jsonb_agg(to_jsonb(s) ORDER BY event_type,status) FROM shapes s) AS inbox_shapes,
 (SELECT jsonb_agg(to_jsonb(a) ORDER BY event_type,location,key) FROM aliases a) AS alias_shapes,
 (SELECT jsonb_agg(to_jsonb(c) ORDER BY event_type,received_via) FROM channels c) AS channels,
 (SELECT jsonb_agg(jsonb_build_object('column',column_name,'type',data_type) ORDER BY ordinal_position) FROM information_schema.columns WHERE table_schema='public' AND table_name='erp_sync_inbox') AS inbox_columns,
 (SELECT jsonb_agg(jsonb_build_object('name',indexname,'definition',indexdef)) FROM pg_indexes WHERE schemaname='public' AND tablename='erp_sync_inbox') AS inbox_indexes,
 (SELECT jsonb_agg(table_name ORDER BY table_name) FROM information_schema.tables WHERE table_schema='public' AND table_name ~* '(session|collection|allocation|sync_event|inbox|recovery|checkpoint|open_set|z_report|fiscal|document_series|parked|kds|wallet|advance)') AS relevant_tables,
 (SELECT count(*) FROM public.sync_inbox) AS alternate_sync_inbox_rows,
 (SELECT jsonb_agg(jsonb_build_object('name',p.proname,'definition',pg_get_functiondef(p.oid))) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='erp_sync_receive_inbox_batch') AS batch_rpc;
