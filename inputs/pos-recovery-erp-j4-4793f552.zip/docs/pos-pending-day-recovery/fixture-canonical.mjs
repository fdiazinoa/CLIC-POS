// Offline fixture canonicalization only. No application, network or database use.
// Input is already parsed plain JSON: raw duplicate keys are not detected here.
// This module is NOT a production JCS parser or a native recovery certification.
import assert from 'node:assert/strict';

function quoted(value) {
    for (let i = 0; i < value.length; i++) {
        const code = value.charCodeAt(i);
        if (code >= 0xd800 && code <= 0xdbff) {
            const next = value.charCodeAt(++i);
            assert(next >= 0xdc00 && next <= 0xdfff, 'INVALID_UNICODE');
        } else {
            assert(code < 0xdc00 || code > 0xdfff, 'INVALID_UNICODE');
        }
    }
    return JSON.stringify(value);
}

export function canonical(value) {
    if (value === null) return 'null';
    if (typeof value === 'string') return quoted(value);
    if (typeof value === 'boolean') return JSON.stringify(value);
    if (typeof value === 'number') {
        assert(Number.isFinite(value), 'NON_FINITE');
        return JSON.stringify(value);
    }
    assert(value && typeof value === 'object', 'NOT_JSON');
    if (Array.isArray(value)) {
        for (let i = 0; i < value.length; i++) assert(Object.hasOwn(value, i), 'SPARSE_ARRAY');
        assert(Object.keys(value).length === value.length, 'NON_JSON_ARRAY_PROPERTY');
        return '[' + value.map(canonical).join(',') + ']';
    }
    assert(Object.getPrototypeOf(value) === Object.prototype, 'NOT_PLAIN_JSON');
    // Emit key/value pairs directly: JSON.stringify of a reconstructed object
    // would reorder integer-index keys (e.g. "2" before "10").
    return '{' + Object.keys(value).sort().map(key => quoted(key) + ':' + canonical(value[key])).join(',') + '}';
}
