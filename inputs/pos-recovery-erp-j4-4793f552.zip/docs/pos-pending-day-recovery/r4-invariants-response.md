# R4 — corrección de invariantes señaladas por POS

> Revisión vigente: [respuesta ERP a POS J2](response-j2.md). Comparación UTF-16 y canonicalización documental corregidas, sin cambiar vectores históricos. Acuerdos todavía provisionales; cierre NOT_GRANTED.

Base documental: `pos-recovery-erp-r4-16968d19.zip`; SHA256SUMS comprobado. Rama nueva desde `origin/clean-erp` (`f332c42d`, con PR2002 integrada). Ambos hallazgos son válidos: R4 verificaba componentes aislados y unicidad de la terna con revisión, insuficientes para validar un candidato completo.

Solo se corrigen documentación, esquema y pruebas offline. **Las reglas siguientes son propuestas ERP pendientes de ratificación bilateral.** Legacy sigue UNKNOWN; exactZEligible=false y closeAuthorization=NOT_GRANTED. Ningún resultado de estos verificadores certifica recuperabilidad o autoriza un cierre.

## 1. Coherencia del candidato completo

`check_close_acceptance_candidate` en [verify-r4.py](verify-r4.py) valida el esquema completo, manifiesto, checkpoint y después sus relaciones. Verificar solo `check_manifest` y `check_checkpoint` deja de ser suficiente. Invariantes conjuntas:

1. `manifest.storageEpoch == checkpoint.storageEpoch`.
2. `manifest.openSetId == checkpoint.openSetId`.
3. `manifest.sealedThrough == checkpoint.highestCommitted` en el corte capturado por ese candidato.
4. `manifest.configurationHash == expectedRevisions.configurationHash`.
5. En etapa final, `manifest.sealedThrough == finalSeal.finalSequence == highestCommitted == highestReceived == contiguousReceived`; `finalSeal.chainHash == checkpoint.chainHash`, gaps vacío y unknownTailPossible=false.

Todos los contadores son strings decimales canónicos y las comparaciones de orden usan enteros exactos. No se permite mezclar el manifiesto de un corte con un checkpoint más reciente de otra operación/conjunto; se requiere volver a construir y validar el candidato, no reemplazar campos aislados.

Se agrega el discriminante obligatorio `validationStage`:

| Etapa | Checkpoint | Resultado semántico |
|---|---|---|
| PROGRESS_ONLY | finalSeal=null, unknownTailPossible=true; puede tener recepción incompleta/gaps | PROGRESS_ONLY; nunca admisible como sello final |
| FINAL_SEAL_CANDIDATE | finalSeal presente, gaps vacío, unknownTailPossible=false y las igualdades finales | FINAL_SEAL_COHERENT_NOT_AUTHORIZED |

En PROGRESS_ONLY, el nombre heredado `manifest.sealedThrough` expresa **el extremo propuesto del corte**, igual a highestCommitted, no evidencia de que esté sellado. Puede superar contiguousReceived. El candidato R4 anterior se etiqueta explícitamente como progreso. Cambiar solo su etiqueta a FINAL_SEAL_CANDIDATE es inválido. Se mantiene el nombre para minimizar cambios del borrador; la nomenclatura wire definitiva sigue pendiente.

Un sello final admisible **para esta validación estructural/semántica** requiere las igualdades anteriores. No basta para demostrar admisibilidad operacional: hashes aquí son marcadores sintéticos y faltan preimágenes/cadena, recepción durable, congelación de escritores y aceptación concurrente. Aun con prefijo totalmente recibido, sin finalSeal solo hay progreso. La continuación de la época en otro openSetId no cambia retroactivamente el checkpoint congelado del conjunto anterior.

Los cuatro desajustes reportados tienen negativos independientes: epoch_mismatch, open_set_mismatch, manifest_cut_mismatch y configuration_hash_mismatch. Se añaden final_sequence_mismatch, chain_hash_mismatch, progress_claims_final, final_unreceived_tail y progress_proposed_cut_mismatch. Cada uno comprueba su rechazo específico para evitar un PASS causado por otro error accidental.

## 2. Una sola revisión seleccionada por operación

Dentro del ámbito autenticado del candidato, la identidad operacional es **(kind, originalId)**; revision es la versión seleccionada de esa identidad. La selección no puede contener la misma operación dos veces, aunque cambien revision, hash o commercialType.

- `members` selecciona a lo sumo una revisión por identidad.
- `dependencies` también selecciona a lo sumo una revisión por identidad.
- La intersección entre ambas listas debe estar vacía por identidad, **independientemente de la revisión**.
- El historial de revisiones se conserva aparte del conjunto de cálculo, con sus originales/referencias inmutables. No se descarta historia para satisfacer unicidad ni se suman revisiones históricas como operaciones adicionales.

La revisión elegida debe corresponder al corte demostrado. Este verificador no elige automáticamente la mayor revisión ni transforma dos miembros en uno: rechaza el manifiesto ambiguo. Acordar y probar el journal que sustenta esa elección continúa pendiente. Se aplica después del mapping de tipos ya propuesto: SALE/CREDIT_NOTE son TRANSACTION y ADVANCE comparte identidad COLLECTION; no se pueden usar esos alias para duplicar una operación.

Positivos: manifiesto con una revisión seleccionada y ambas revisiones en `revisionHistory` externo; dos operaciones distintas sin colisión; progreso completo; progreso con gaps. Negativos: dos revisiones en miembros, dos en dependencias, intersección con misma revisión, intersección con revisión distinta y duplicado literal. El historial de la fixture no forma parte de members ni de dependencies.

## Qué comprueba cada capa

| Regla | JSON Schema | Validación semántica |
|---|---|---|
| Campos requeridos, tipos, UUID (con FormatChecker), digest hexadecimal y decimal canónico | Sí | — |
| Etapa conocida; progreso sin sello y cola desconocida; etapa final con sello, gaps vacío y cola declarada conocida | Sí, mediante if/then/else | Resultado de etapa explícito; nunca autorización |
| Duplicados de objetos idénticos en arrays | Sí, uniqueItems | — |
| Igualdad de época, conjunto, configuración y extremos del corte entre objetos | No | check_close_acceptance_candidate |
| Orden numérico de watermarks/gaps e igualdad de secuencia/hash del sello | No | check_checkpoint y validación conjunta |
| UUID closeId distinto de closeEventId | No | check_manifest |
| Una revisión por identidad e intersección miembros/dependencias sin considerar revisión | No | check_manifest |
| Hash criptográfico real, conjunto completo, ámbito autorizado y revisión correcta del corte | No | No demostrado por estas pruebas; requiere protocolo/evidencia futura |
| Atomicidad local, exclusión de todos los escritores y aceptación concurrente | No | No demostrado por estas pruebas |

## Reproducción y resultados

Archivos: [closure-protocol.schema.json](closure-protocol.schema.json), [r4-evidence.fixtures.json](r4-evidence.fixtures.json), [r4-invariants.fixtures.json](r4-invariants.fixtures.json) y [verify-r4.py](verify-r4.py). No cambian originales, fórmulas, contrato de descarga/importación ni su autorización.

Con Node y Python con `jsonschema==4.25.1`, desde la raíz del paquete:

```sh
node docs/pos-pending-day-recovery/verify-fixtures.mjs
python docs/pos-pending-day-recovery/verify-schema.py
python docs/pos-pending-day-recovery/verify-r4.py
```

PASS: verificaciones anteriores conservadas; **4 positivos del candidato completo y 14 negativos independientes nuevos**. Los casos y códigos esperados están en r4-invariants.fixtures.json. Todos son ejemplos de especificación offline; no se ejecutaron ventas, cierres, endpoints ni motores POS/ERP.

## Pendientes visibles

- Recepción/persistencia de Collection, anticipos y wallet independiente; vínculo wallet histórico.
- Ratificación de versiones nativas y mapping, preimágenes/hashes, cadena y sello OPEN_SET verificables, nomenclatura del corte de progreso y elección de revisión respaldada por journal.
- Atomicidad local en cada backend y aceptación concurrente con todos los escritores, reutilizando pairing/takeover vigentes.
- Cuarentena fiscal no reutilizable y reasignación sin solapamientos; release no acredita cuarentena.
- Retención/materialización y demás acuerdos listados en [response-r4.md](response-r4.md).

La corrección de ambos huecos mejora el rechazo de candidatos incoherentes; no convierte las propuestas pendientes en acuerdos ni habilita cierre exacto.
