# ERP — revisión POS J2 y corrección de verificadores documentales

> Revisión vigente: [respuesta ERP a POS J3](response-j3.md), intenciones, perfiles y propuesta de raíz durable. Solo documentación; UNAGREED y cierre NOT_GRANTED.

Entrada `pos-recovery-j2-e4bc10f.zip`, commit POS `e4bc10f56edd518987e3b86bea0afef2326ee999`, [PR CLIC-POS #558](https://github.com/fdiazinoa/CLIC-POS/pull/558) consultada: MERGED, base develop. Rama ERP creada desde `origin/clean-erp`, base `c546407e`, que incluye R4 a7e490d6. Se leyó primero [POS_RESPONSE_J2.md](pos-j2-evidence/docs/pos-recovery-journal/POS_RESPONSE_J2.md).

**Solo documentación, fixtures y verificadores offline. UNAGREED; legacy UNKNOWN, exactZEligible=false y closeAuthorization=NOT_GRANTED.** Lo aceptado provisionalmente en esta revisión no autoriza implementar journal, endpoints, migraciones, cálculo, pairing/takeover ni lógica operacional. No se accedió a producción ni se crearon ventas/cierres de prueba.

## Diferencias concretas y verificación

**Hallazgo POS resuelto en el modelo J2.** validateCalculationInput valida los nombres de los tres arrays, las referencias de tres campos, el kind correspondiente, la revisión seleccionada, unicidad, cobertura y exclusión de dependencias por identidad. No admite WALLET autónomo. Probamos de nuevo tipo incorrecto en dos arrays, revisión antigua, duplicado y omisión después de reconstruir el grafo completo y sus hashes: todos se rechazan por la razón semántica esperada. También se rechaza la venta cerrada en cálculo aun con revisión distinta y configurationHash recalculado. El positivo [sale-B,sale-A] conserva su orden aunque el manifiesto esté ordenado [sale-A,sale-B]. Son pruebas de clasificación/selección, no del cálculo nativo o de importes recuperables.

**Hallazgos ERP corregidos aquí:**

- `verify-r4.py`: las tres claves `(kind,originalId,revision)` se comparan por unidades UTF-16 mediante codificación estricta UTF-16BE. Unicode inválido se rechaza. Hay positivos para miembros y dependencias con U+1F600 antes de U+E000; negativos invertidos y sustitutos aislados alto/bajo en ambas listas. La unicidad sigue siendo por `(kind,originalId)`, sin considerar revisión, y ambas listas siguen disjuntas por identidad.
- `verify-fixtures.mjs` utiliza el nuevo `fixture-canonical.mjs`: emite pares de claves/valores ya ordenados, sin reconstruir un objeto que JSON.stringify volvería a ordenar por índices numéricos. Incluye validación Unicode, números finitos y formas JSON del corpus. `verify-j2.mjs` prueba claves numéricas anidadas, orden UTF-16, arrays conservados, órdenes incorrectos, Unicode inválido y valores no JSON.
- Se conservan los tres vectores ERP originales, los siete J1 y los cuatro propios ERP. Ningún hash histórico fue recalculado ni ningún original fue editado. `published-artifacts.sha256.json` fija el SHA256 de siete archivos históricos completos; el verificador comprueba sus bytes. También se compararon directamente vectors.json J1 y erp-own-vectors.json contra las copias archivadas: idénticos.

Los canonicalizadores siguen limitados a fixtures/JSON ya parseado. No son parsers de producción que detecten claves duplicadas raw, ni una certificación completa de JCS. La corrección conserva la regla UTF-16 previamente documentada; no cambia la política de hashes ni normaliza fechas/cadenas. Referencia normativa de la regla: [RFC8785 §3.2.3](https://www.rfc-editor.org/rfc/rfc8785.html#section-3.2.3).

## Contraste de los escenarios nuevos

| Escenario | Evidencia comprobada | Límite |
|---|---|---|
| Venta cerrada y abono nuevo | El archivo previo conserva SALE-CLOSED revisión2; nueva revisión3 referencia su originalContentHash; solo COLLECTION entra como miembro y TRANSACTION revisión3 queda READ_ONLY. Ambas mutaciones comparten commandId. El archivo anterior no se modifica. | No ejecuta allocations ni deuda ni demuestra commit atómico. La venta y su historia no vuelven a sumarse. |
| NEW_EPOCH | Genesis nuevo, posiciones1/2, nueva época/conjunto; previousContentHash de la revisión3 coincide con el antecedente del archivo verificado. No reinicia esa identidad en revisión1. | La raíz confiable se suministra sintéticamente. No recupera ni certifica la cola perdida de otra jornada abierta. |
| SAME_EPOCH_SUFFIX | Mismo storageEpoch, nuevo openSetId; posiciones3/4 después del prefijo2; el primer eslabón usa el chainHash previo, sin nuevo genesis. | Solo si la base/época realmente continúa. Un sustituto tras pérdida no puede declararse continuación basándose solo en el ZIP. |

verify-lineage.mjs recorre el archivo previo completo y valida selección/antecedentes. Los tests ERP contrastan además el hash previo, el commandId compartido, el encabezado de cadena y el hash de configuración mediante el canonicalizador ERP corregido, y comprueban rechazo de raíz desconocida. Los dos casos parten de un cierre anterior conservado, no de un final perdido. Reanudación arbitraria con páginas/pruebas compactas, múltiples terminales/épocas y fuentes desplegadas sigue fuera de lo demostrado.

## Los ocho acuerdos

### 1. Preimágenes, versiones e intentHash — aceptado provisionalmente; evidencia pendiente

Se mantienen las preimágenes J1 y los ocho campos de originalContentHash R4 sin cambios. Los 51 vectores recibidos —incluidos los anclajes y continuaciones— coinciden con los bytes/digests calculados por ERP. originalSchemaVersion sigue ligado por entryHash; Record.hash sigue siendo digest del snapshot ERP con sus estados congelados, no originalContentHash. Un digest correcto no prueba origen ni cola vacía.

**Pendiente antes de implementar:** tabla versionada de intentHash por comando (venta/NC/Collection/movimiento/cierre y otros productores), intención inmutable, precondiciones/antecedente/reserva, resultados asignados y reglas para IDs/relojes. No usar un objeto abierto sin definición. También faltan perfiles completos de originales/configuración/declaración/report, límites numéricos, parser raw y corpus general. No se aprueba un DTO parcial por pasar los vectores.

### 2. Control de cierre y retención — aceptado provisionalmente; evidencia pendiente

Z/manifiesto/sello quedan fuera de la secuencia operacional que sellan, eliminando circularidad. Commit propuesto todo-o-nada de artefactos, membresía, reserva/número, comando/outbox de control y siguiente conjunto. El evento de control conserva closeEventId; ACK no borra originales ni sellos ni autoriza reaplicación.

Retención de snapshot/recibo de importación distinta de aceptación financiera/de cierre. Un TTL de snapshot no puede habilitar recreación de un cierre antiguo. Se necesita archivo/tombstone durable que conserve identidad/digest y prevenga duplicados durante toda la vida de reintento acordada. **Pendientes** duración/custodia/restauración del archivo y pruebas de durabilidad, commit local por backend y resolución del duplicate eventId parcial Android. Ningún endpoint de recepción de control se declara existente.

### 3. acceptanceDigest e idempotencia — aceptado provisionalmente; evidencia pendiente

Correcto exigir unicidad independiente de `(scope,closeId)` y `(scope,closeEventId)` frente a reutilización divergente, no solo de la pareja. acceptanceDigest se recomputa sobre artefactos verificados y no incorpora activationId. Auth/scope frescos primero; lookup de aceptación estable antes de CAS para cierre nuevo. Aceptación existente con contenido idéntico devuelve estado sin reaplicar aunque cambie corte/activación; contenido divergente es conflicto. SEALED/ACCEPTED/APPLIED siguen separados.

**Pendientes** transacción/índices/retención y participación de todos los escritores con pruebas de carreras y crash. Un registro recibido comercialmente no acredita automáticamente la nueva aceptación/control ni su digest.

### 4. proposedThrough / sealedThrough — requiere cambio explícito de versión

La propuesta de nombres es aceptable para la siguiente versión discriminada: proposedThrough solo en progreso y sealedThrough solo en final, nunca ambos. **No se adopta silenciosamente en R4.** Aquí se conserva validationStage y la forma existente. La versión/migración deberá definir traducción, rechazo de mezclas y las mismas igualdades de época/conjunto/configuración/corte/sello. Hasta ese acuerdo, el candidato compatible R4 es solo eso; los nombres J2 no implican compatibilidad automática. Sin sello previo sigue unknownTailPossible=true para una cola perdida.

### 5. Unicode y canonicalización — aceptado provisionalmente; corrección documental ERP completada

La regla UTF-16 y la emisión de pares ya están aplicadas a los verificadores ERP; se añadieron positivos/negativos y se preservaron los bytes históricos. Los arrays de cálculo no se reordenan. Falta certificar un corpus general y el parser de transporte, incluyendo claves duplicadas, Unicode y números límite. No se copia este helper documental al producto como una biblioteca certificada.

### 6. calculationInputOrder — aceptado provisionalmente; hallazgo POS corregido

Se ratifica provisionalmente la ubicación en configuration, ligada por configurationHash, con arrays por tipo y referencias exactas a la revisión seleccionada. J2 corrige la validación incluso al reconstruir hashes. Advance comparte COLLECTION. Dependencias, versiones históricas y wallet autónomo no se cuentan como entradas adicionales.

**Pendientes** snapshot histórico completo de dependencias de configuración/entorno y contraste con selectores, importes/anexos e impresión reales. La forma parcial de las fixtures no acredita esos campos ni autoriza corregir el cálculo actual.

### 7. Historial, continuidad y pos.journal.resume.v1 — aceptado provisionalmente; fuente confiable pendiente

Se acepta provisionalmente la preimagen exacta propuesta:

```text
{domain:"pos.journal.resume.v1",scope,mode,storageEpoch,openSetId,
 priorStorageEpoch,priorOpenSetId,priorFinalSequence,priorChainHash,
 priorAcceptanceDigest}
```

Su ubicación como objeto completo `configuration.resumeAnchor` es coherente para este candidato: queda ligada por configurationHash → manifestHash → sealHash → acceptanceDigest. El digest de resumeAnchor publicado es un vector derivado; no reemplaza el objeto ni lo convierte en firma. No se añade un campo silenciosamente a las preimágenes originales genesis/entry/originalContentHash. El perfil versionado de configuration debe incorporar esta semántica y su validación completa antes de adoptar el wire final.

**Fuente confiable exigida:** un registro/archivo durable ERP previamente recibido y validado bajo scope canónico y autorización vigente, con aceptación técnica y artefactos del cierre anterior (originales/revisiones, manifiesto, sello, configuración y digests), o una referencia a ese archivo verificable desde dicho registro. La raíz esperada debe obtenerse por un camino de confianza independiente del paquete que se pretende importar. No basta tomar priorAcceptanceDigest del mismo archivo/JSON, del dispositivo sustituto, de un hash que puede recalcularse o de contadores coincidentes. Debe verificarse la correspondencia con el ámbito y artefactos guardados; la aplicación comercial puede seguir en otro estado.

Los anclajes del ZIP son valores sintéticos que el test pasa como argumento separado. **No existe aquí evidencia de esa recepción/aceptación remota confiable ni un protocolo autenticado implementado para obtenerla.** El rechazo con raíz diferente prueba comparación de contenido contra la hipótesis del test, no autenticidad. También sigue pendiente acreditar que una base puede continuar la misma época y que no reusa secuencias; tras pérdida se crea nueva época y se conserva procedencia de los antecedentes, sin rellenar UNKNOWN. La historia cerrada permanece fuera de las sumas aunque se revise después.

### 8. Capacidades ERP — pendiente de evidencia e implementación aparte

| Capacidad | Dependencia pendiente |
|---|---|
| Collection / Advance | Emisor/receptor/persistencia operacional y respaldo de allocations/vínculos históricos verificables; no demostrado por la fixture |
| Wallet independiente | Receptor equivalente al destino POS /api/sync/operational/events no encontrado en ERP auditado; moneda/cliente/referencia histórica comprobables |
| CAS común | Todos los escritores directos, batch/RPC, genéricos, administrativos, configuración/series/revisiones/canales pertinentes bajo guard común; pruebas de dos conexiones, crash, ACK y takeover |
| Reserva fiscal perdida | Cuarentena del intervalo completo no reutilizable sin afirmar que fue emitido; release actual no equivale a cuarentena |
| Reasignación fiscal | Ámbito/tipo correctos y no solapamiento transaccional; SELECT previo al INSERT, end+1 o next remoto no son garantía |
| Series internas | Asignación exclusiva/revisión y commit coherente con el cierre; nunca zReports.length+1 |

Se conserva el estado previamente auditado, sin nueva auditoría de producción. SQLite POS no demuestra ninguna capacidad ERP. Se reutiliza pairing/takeover vigente; no se rediseña. Los acuerdos provisionales anteriores no autorizan empezar esas implementaciones.

## Reproducción y resultados

POS recibido, archivos preservados bajo pos-j2-evidence:

```sh
node docs/pos-pending-day-recovery/pos-j2-evidence/docs/pos-recovery-journal/verify-vectors.mjs
node docs/pos-pending-day-recovery/pos-j2-evidence/docs/pos-recovery-journal/verify-lineage.mjs
python3 docs/pos-pending-day-recovery/pos-j2-evidence/docs/pos-recovery-journal/verify-bytes.py
```

Resultados: PASS, 7 vectores canónicos +13 digests y24 negativos; cuatro vectores ERP intactos; dos escenarios de continuidad y24 negativos; 51 comprobaciones Python de bytes/JSON/SHA256. Este último no es un segundo JCS completo. SHA256SUMS de entrada coincide.

ERP, con Node y Python con jsonschema==4.25.1:

```sh
node docs/pos-pending-day-recovery/verify-fixtures.mjs
python docs/pos-pending-day-recovery/verify-schema.py
python docs/pos-pending-day-recovery/verify-r4.py
node docs/pos-pending-day-recovery/verify-j2.mjs
```

Resultados: PASS, verificaciones previas conservadas; dos positivos y seis negativos UTF-16 para miembros/dependencias; 51 vectores contrastados por el canonicalizador ERP; positivos de claves numéricas/UTF-16 y rechazos de orden incorrecto/Unicode/valores no JSON; cinco negativos de grafo recomputado; contraste de ambos escenarios, dependencias y ancla no confiable; siete archivos históricos completos byte-idénticos. No se reescribieron fixtures históricos ni se regeneraron sus hashes para conseguir PASS.

`inputs/pos-recovery-j1-erp-review.zip` se archiva como procedencia. Su verify-review.py reproduce problemas **antiguos J1/R4** y no se usa para evaluar esta corrección J2. Los hashes de fuentes POS se conservan como evidencia declarada; no se accedió a su checkout ni se verificó despliegue. Los únicos cambios ERP fuera de archivo de evidencia son documentación y verificadores bajo este directorio.

La siguiente decisión requiere cerrar los perfiles/intenciones, fuente confiable y garantías pendientes; pasar estas pruebas no certifica recuperabilidad ni autoriza implementación.
