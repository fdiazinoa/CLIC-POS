# ERP — contraste POS J3, intenciones y propuesta de raíz durable

> Revisión vigente: [respuesta ERP a POS J4](response-j4.md), intención v2 y límites de subperfiles. Solo documentación; acuerdos provisionales y cierre NOT_GRANTED.

Entrada: `pos-recovery-j3-5a76ecd.zip`; se leyó primero [POS_RESPONSE_J3.md](pos-j3-evidence/docs/pos-recovery-j3/POS_RESPONSE_J3.md). PR [CLIC-POS #559](https://github.com/fdiazinoa/CLIC-POS/pull/559) consultada: MERGED, head `5a76ecd76a2626331fb3849e0052c2c09718b29d`, base develop. ERP trabaja desde `origin/clean-erp` (`f4e4d78b`, con J2 d680fa91 integrado).

**Solo revisión y modelos documentales offline. Estado UNAGREED. Legacy UNKNOWN, exactZEligible=false, closeAuthorization=NOT_GRANTED.** No se implementa almacenamiento, journal, endpoints, migraciones, cálculo, pairing/takeover ni otra lógica operacional. No se consulta producción ni se ejecutan ventas/cierres de prueba. Los nombres de registros, campos y errores que siguen son propuestas, no recursos desplegados.

## Resultados y discrepancias

SHA256SUMS del ZIP coincide. `verify-contract.mjs`: PASS, ocho bindings versionados y46 negativos. `verify-bytes.py`: PASS, ocho bytes/digests. Estos resultados son correctos dentro del alcance declarado de binding.

El nuevo [verify-j3.mjs](verify-j3.mjs) añade ocho positivos y **89 negativos independientes**, con rehash de artifacts e intención, reintentos contra resultado guardado y once fallos de raíz. Conserva la evidencia POS sin modificarla. Concreta estos hallazgos:

1. **Fecha imposible aceptada:** `preparedAt=2026-02-30T12:00:00.000Z` pasa regex+Date.parse porque JavaScript normaliza el calendario. El control documental ERP exige round-trip ISO exacto además de la forma original; lo rechaza como PREPARED_AT_CALENDAR. POS debe incorporar esa comprobación al próximo verificador documental.
2. **Reserva vacía aceptada:** reservationId="" pasa el binding. Se propone rechazar vacío/blancos y diferenciar null explícito para una modalidad interna comprobada. El contrato necesita el formato de IDs y una regla semántica por comando/perfil; no impongo UUID a seriesId o reservationId sin acuerdo.
3. **Envoltura de artifact abierta de hecho:** el hash incluye cualquier campo añadido al objeto, pero checkIntent no exige exactamente schemaVersion/role/document. La revisión ERP rechaza extras de envoltura aun con ambos hashes recalculados. Las propiedades observadas dentro de document siguen conservándose; eso no las certifica.
4. **Campos posteriores al hash:** un nuevo draft con newRevision/journalSequence/seriesNumber u otro campo asignado pasa el binding si se recalculan hashes. El control ERP documental rechaza los campos conocidos de asignación en los roles *Draft. No borra nada del original ni aplica esa exclusión a originalBefore/documentos históricos. Faltan schemas y reglas condicionales completas por ruta.
5. **Raíz parcialmente comprobada:** checkAnchor recibido permite domain y mode arbitrarios. Es un modelo limitado de binding, no un cliente de producción; el modelo ERP nuevo exige domain, modos conocidos, separación de épocas/conjuntos y correspondencia contra archivo/registro. Una raíz sintética correcta sigue sin ser autenticidad remota.
6. **Semántica aún sin especificar:** todos los ocho fixtures usan expectedSeries=[] y artifacts mínimos. No prueban precondición de numeración, propiedad/límites de reserva, planes monetarios/inventario, heads, identidad del cliente ni perfiles nativos. No es un fallo de SHA256: un contenido semánticamente inválido también tiene hash válido.

No se recalculan hashes históricos para corregir errores. Los negativos nuevos construyen copias adversas y recalculan sus propios hashes para demostrar que el rechazo no depende de corrupción accidental. El verify-review.py archivado sigue siendo una reproducción de problemas antiguos, no una evaluación de J3.

## 1. Ocho comandos, intentHash y perfiles — requiere cambios; envolturas aceptadas provisionalmente

La lista de ocho comandos, domain y version1, roles exactos y versiones por rol queda contrastada. El orden canónico de roles y series forma parte de la intención, mientras los arrays internos de planes conservan su orden. La intención debe permanecer congelada: commandId/IDs técnicos/preparedAt, ámbito, época/conjunto, expectedSetRevision, expectedSeries y artifacts se ligan por intentHash. Un artifact o antecedente ausente bloquea; ausencia nunca significa cero/creación probada.

| Comando | Roles obligatorios comprobados | Reglas adicionales pendientes |
|---|---|---|
| SALE_CREATE | saleDraft, inventoryPlan, paymentEvidence | IDs de documento/líneas/pagos; consistencia de importes/impuestos/cambio/FX; deltas por producto/variante/almacén/unidad; estado del pago e identidad de reconciliación; serie cuando corresponda |
| REFUND_CREATE | refundDraft, originalBefore, inventoryPlan, refundEvidence | REFUND y vínculo NC/original/líneas; head previo dentro del ámbito; límites/cantidades; método/disposición CARD/STORE_CREDIT documentados. CASH, multimoneda y VOID comercial siguen bloqueados |
| COLLECTION_CREATE | collectionDraft, allocationPlan, documentsBefore, customerBefore | IDs/refs/heads por cada allocation y cliente; recibido/aplicado/no aplicado y FX; no duplicar ingreso ni reabrir documentos; serie y plan de deuda coherentes |
| BOOKING_ADVANCE_CREATE | collectionDraft, bookingBefore, customerBefore | bookingActivityId y Activity/head/cliente coherentes. Definir si allocations deben estar vacías; si se permiten, qué plan y antecedentes exige. No inventar otra identidad ADVANCE |
| CASH_CREATE | cashDraft | IN/OUT, moneda e importe históricos, signo/dirección, operador/motivo/timestamp y prueba de movimiento de apertura real |
| WALLET_POST | walletDraft, walletBefore, linkedDocument | Tipo/importe firmado; wallet/cliente/moneda/head históricos; vínculo resuelto o ausencia justificada tipada; referencia displayId no promovida a UUID |
| FISCAL_REVISION | originalBefore, fiscalResult | Revisión/identidad/NCF/proveedor previos; resultado observado y timestamp originales; qué campos fiscales pueden cambiar; no reemisión ni nuevo SALE |
| CLOSE_SET | memberSelection, configuration, declaration, previousClose | Miembros/dependencias/revisiones/orden/corte coherentes; contexto y declaración completos; cierre previo o PROVEN_FIRST demostrados; reserva, IDs y resultado de control persistido |

**Ambigüedad de IDs de CLOSE_SET:** el texto exige IDs técnicos congelados antes de intención, pero no identifica un campo/rol explícito para closeId, closeEventId y el siguiente openSetId, y la lista assignedAfterIntent tampoco resuelve todos esos IDs. Propuesta ERP para discusión: fijar closeId/closeEventId antes y ligarlos mediante artifact de control versionado; si se decide asignar alguno dentro del commit, declararlo expresamente como resultado persistido una sola vez. No añadirlo unilateralmente a un rol actual ni derivarlo en cada retry. Falta ratificar dónde y bajo qué versión.

**Reserva/configuración:** expectedSeries=[] solo puede admitirse con prueba de que ese comando no usa/condiciona numeración. null no equivale a SAFE. Cada perfil debe relacionar reserva/serie/tipo/ámbito con drafts, propiedad y límites, y determinar expectedNext y avance exactos. Los parámetros de configuración/resolución que influyan en la intención/planes también deben quedar ligados por un artifact versionado; no leer configuración nueva para reinterpretar intención congelada.

**Campos asignados después:** posiciones y revisión nueva, cadena, número aún no emitido, reloj de cierre/fallback, manifest/seal/acceptance y transporte no se regeneran al reintentar. Se guardan juntos como resultado. Los números, fechas, hashes y revisiones ya históricos en antecedentes permanecen íntegros. Draft nuevo y original recuperado necesitan perfiles distintos; no aplicar una eliminación genérica de esos nombres. La decisión de qué IDs se asignan cuándo debe completar la tabla anterior.

**Reintento:** en el modelo se autentica ámbito primero, se calcula/valida binding y se busca por `(scope,commandId)`; identidad+intentHash idénticos devuelven el resultado persistido, sin upsert ni efecto. Hash diferente produce COMMAND_ID_CONFLICT, aun si el cambio fue expectedSetRevision o un artifact correctamente rehasheado. Si el comando no existe, el modelo devuelve NEW_COMMAND_BLOCKED_PENDING_SEMANTICS_AND_CAS. No se convierte un PASS de binding en permiso. Una preparación nueva tras conflicto debe ser explícita; no sustituye un comando ya confirmado. La aceptación idempotente del cierre por closeId/closeEventId/acceptanceDigest sigue siendo otro nivel.

## 2. Control de cierre y retención — aceptado provisionalmente; política pendiente

Se conserva el control fuera del prefijo que sella y su commit conjunto propuesto. No se confunde TTL de descarga con vida de identidad:

| Clase | Propuesta técnica ERP | Al vencer/archivar |
|---|---|---|
| Snapshots/páginas/cursors | TTL de captura, propuesta previa24h sin SLA aprobado | Invalidar descarga; nueva captura con identidad/corte nuevos, sin mezclar páginas ni borrar fuente |
| Recibos/idempotencia de importación | Propuesta previa7d, independiente de comandos | Vencimiento no borra identidad financiera ni habilita cierre; no usar recibo para demostrar aplicación |
| Comandos | scope/commandId, intentHash, versión, resultado estable/IDs asignados y vínculo de archivo durables | Mantener lookup activo o tombstone consultable; mismo ID divergente siempre conflicto |
| Aceptaciones de cierre | Unicidad separada scope/closeId y scope/closeEventId, acceptanceDigest, estado técnico, revisión y vínculo durable | No recrear aunque no haya blob en almacenamiento caliente; aplicación comercial separada |
| Originales/revisiones/config/declaración/Z/sello | Archivo completo y verificable según necesidad de restauración acordada | ACK no purga. Si falta archivo, ARCHIVE_UNAVAILABLE; tombstone no basta para restaurar |
| Tombstones | Identidad/digest/estado/revisión, motivo y localizador/estado de archivo mínimo | No se eliminan mientras pueda existir reintento; no convierten conflicto en comando nuevo |

Propuesta conservadora: sin GC automático de identidades/comandos/aceptaciones/sellos hasta ratificar política. Lookup de deduplicación debe abarcar activo y archivo/tombstone de forma coherente antes de cualquier recreación. Si negocio exige eliminar también las claves de deduplicación, debe definir primero un corte de protocolo que rechace irrevocablemente los espacios de identidad/épocas antiguos; si no se puede demostrar, no se aprueba ese borrado. Un UUID nuevo tampoco permite reemitir una operación histórica.

Pendientes negocio/operación: plazos por clase y obligaciones aplicables, volumen/costo, custodio, replicación/copias, restauración verificable, acceso al archivo, RPO/RTO, disponibilidad del lookup, tratamiento de bajas de terminal/tenant y evidencia ante borrado. No se fijan plazos legales ni se afirma que exista archivo durable hoy.

## 3. acceptanceDigest — aceptado provisionalmente; mecanismo ERP pendiente

Se mantienen digest estable recomputado, identidad de closeId y closeEventId separadas, autenticación fresca, lookup de aceptación antes del CAS de nuevo cierre. El cambio de activationId no desconoce una aceptación anterior. APPLIED/FAILED comerciales no cambian identidad técnica. Falta implementar y probar transacción/índices/guard, unicidad en todos los escritores, ACK/crash y retención. Ninguna propuesta de esta revisión ejecuta aplicación comercial.

## 4. Nombres de corte — requiere versión explícita

R4 mantiene validationStage y sus campos actuales. proposedThrough para progreso y sealedThrough para final requiere la siguiente versión discriminada, reglas de migración/rechazo de mezclas y vectores. No se renombra ningún payload publicado. Prefijo recibido sin sello final no demuestra cola vacía; la pérdida permanece UNKNOWN.

## 5. UTF-16/JCS — aceptado provisionalmente; corrección anterior conservada

No hay discrepancia nueva con J2 en claves/miembros. Los verificadores ERP anteriores y sus hashes no cambian. Parser raw de claves duplicadas, límites/representación numérica y corpus general siguen pendientes. El hash no recupera precisión perdida antes del parseo ni autoriza normalizar strings históricos.

## 6. Captura y calculationInputOrder — aceptado provisionalmente como política, validación nativa pendiente

`native-closure.json` contiene14 raíces y156 declaraciones alcanzables;16 están marcadas openShape. Incluye herencia y referencias genéricas, no validadores runtime. El hash fuente de types.ts es evidencia declarada y no reaudita producción. Ni un tipo cerrado ni la captura de todos sus campos valida semántica.

Los artifacts de contract-vectors.json son **ejemplos mínimos de binding** (fixtureOnly/label), no borradores, configuración ni planes completos. Se pueden aceptar para comprobar references/hashes y seguir BLOCKED para ejecución/recuperación.

Reglas/campos todavía necesarios:

- **Originales comunes:** versiones nativas por canal y captura local, identidad/ámbito, procedencia temporal/epoch/posición, head/revisión previa, presencia/null/ausente, campos desconocidos, límites numéricos y claves raw duplicadas. No completar histórico desde maestros actuales.
- **Transaction/pagos:** id producto/cartId línea, identidad única de renglón/pago, cantidades/unidades/modificadores/variantes, precios/tasas/bases/impuestos/descuentos/totales históricos, métodos/gateway/FX/cambio y conciliación; coherencia entre pagos/líneas/documento y representación válida de NC. Transaction.payments any[] y extensiones gateway/fiscales requieren reglas propias.
- **Collection/Advance/wallet/movimientos:** planes/heads y clientes/vínculos coherentes, conservación de moneda/tasa/recibido/aplicado/no aplicado; no reaplicar deuda ni sumar revisiones/efectos dos veces. Identidad wallet y link literal verificados. Moneda/terminal opcionales nativos no se inventan.
- **Configuración:** tipos y reglas de los14 bloques requeridos; CurrencyConfig/PaymentMethodDefinition/taxes y políticas duales/aliases efectivos; opciones por operador, resolvedBaseCurrency, sourceVersions, resolver/defaults efectivos, locale/timeZone, calculationInputOrder y resumeAnchor/PROVEN_FIRST. readCoverage requiere instrumentación real de cada selector/helper y prueba de cierre de dependencias; hoy no existe. Los bloques ausentes/null precisan representación tipada, no marcador ambiguo.
- **Declaración:** presencia y valor de cashCountedByCurrency, paymentMethodDeclarations, denominationBreakdown, notes, requireCashFundOnZ, fixedCashFundAmount, cashToLeaveInDrawer/cashToWithdraw, operador y contexto; relaciones denominaciones/moneda/método y condiciones de presencia. Separar entradas declaradas de resultados calculados. No reconstruir declaración ni openedAt perdidos.
- **Z/impresión:** ZReport completo y anexos/aliases persistidos, IDs/serie/conteo/baseCurrency, selección histórica y hashes; contexto público de empresa/receipt, activos/versiones, renderer/layout/opciones/locale/anexos y dependencias por sección. Pruebas nativas por canal y muestras autorizadas antes de afirmar reimpresión fiel. Importar no imprime, envía correo ni emite fiscalmente.

Captura completa conserva propiedades observadas de los objetos de negocio; no autoriza copiar credenciales de BusinessConfig/TerminalConfig. La exclusión explícita integrationConfig del nuevo perfil no se aplica retroactivamente al original recibido. Falta una política versionada de clasificación/captura para campos desconocidos que requieran tratamiento especial. No se presume exhaustividad de configuración/impresión por haber exportado tipos.

## 7. Registro durable ERP y fuente confiable — propuesta concreta, pendiente de evidencia

Se conserva `pos.journal.resume.v1` dentro de configuration.resumeAnchor. La raíz esperada debe provenir de un camino autenticado **independiente del paquete importado**. Se propone un registro lógico versionado, sin afirmar tabla/ruta creada:

| Grupo | Contenido durable requerido |
|---|---|
| Identidad/ámbito | recordVersion, registryId, registryRevision decimal; tenant/company/store/terminal canónicos; closeId y closeEventId con unicidad independiente |
| Corte/antecedentes | storageEpoch, openSetId, finalSequence decimal, chainHash, cierre previo/prueba de primero, revisiones y selección de miembros/dependencias; relación a comandos/revisiones inmutables |
| Integridad | acceptanceDigest, manifestHash/sealHash/reportHash/configurationHash/declarationHash, digest y versión del contenedor de archivo; algoritmo/canonicalización versionados |
| Artefactos | Z/manifiesto/sello completos, originales/revisiones y entradas/predecesores necesarios, configuración/declaración/orden/contexto históricos y evidencias de reserva/selección; no solo IDs o digests |
| Estados | technicalAcceptance y aceptación/validación durable; commercialApplication separado; retención AVAILABLE/ARCHIVED/TOMBSTONE_ONLY/UNAVAILABLE y metadatos de archivo |
| Custodia/procedencia | localizador interno versionado, comprobación de disponibilidad/integridad, registro de recepción autorizada y validación, revisión/tombstone; credencial no se obtiene del paquete |

El ejemplo [j3-root.fixtures.json](j3-root.fixtures.json) usa plantilla sintética y archivo previo J2 completo. El verificador calcula y compara digest del archivo, artefactos, cadena/acceptance y coordenadas. No es esquema final del almacén ni implementación de una API. RecordHash del snapshot de descarga no sustituye esos digests.

Flujo futuro propuesto:

1. Reutilizar auth/pairing/takeover vigentes y obtener ámbito canónico autorizado. La solicitud solo identifica registro/cierre; no proporciona la raíz de confianza ni selecciona otro tenant mediante el original.
2. Leer el registro técnico independiente bajo ese ámbito, con revisión. Si el paquete trae un digest, se usa como dato a contrastar, nunca como raíz esperada. El registro debe acreditar ACCEPTED técnico, no solo RECEIVED en inbox comercial.
3. Resolver el archivo mediante localizador administrado por ese registro. Recomputar contenedor, artefactos, cadena/predecesores, selección y acceptanceDigest; comprobar ámbito, IDs, revisión de registro y relación de cierre anterior. Controlar cambio concurrente de registryRevision durante lectura.
4. Comparar todos los campos de resumeAnchor y su domain/modo. NEW_EPOCH exige identidad nueva de base; SAME_EPOCH_SUFFIX exige prueba durable de continuidad de esa misma base/época y secuencia. El test puede comparar UUID/posición pero no acredita la vida real de la base. No certificar cola perdida.
5. Aun con raíz íntegra, semántica nativa, cobertura, reserva y CAS siguen pendientes de validación para una acción nueva. Lectura/rescate de evidencia permanece separado de autorización exacta.

Errores lógicos propuestos (sin asignar rutas ni códigos HTTP desplegados):

| Error | Condición / tratamiento |
|---|---|
| AUTH_REQUIRED / ROOT_SCOPE | Credencial inválida/ámbito incorrecto; rechazar sin aceptar raíz del paquete ni revelar registros ajenos |
| UNKNOWN_ROOT | Registro independiente ausente/no verificable; mantener UNKNOWN y bloquear continuidad exacta |
| ROOT_NOT_ACCEPTED | Solo recepción comercial/técnica incompleta; no tratar como aceptación confiable |
| ROOT_REVISION_CHANGED | Registro cambió respecto a la consulta; releer consistente, no mezclar cortes |
| ARCHIVE_UNAVAILABLE | Registro/tombstone existe pero faltan originales o archivo recuperable; puede reconocer identidad, no restaurar exactamente ni recrear cierre |
| ARCHIVE_CORRUPT / ROOT_BINDING | Archivo, digest, coordenadas o antecedente divergentes; detener exactitud, conservar diagnóstico y resolver contra fuente confiable |
| ANCHOR_DOMAIN / ANCHOR_MODE | Versión/modo no reconocido; rechazo explícito, no inferencia |
| ROOT_UNAVAILABLE | Camino de confianza temporalmente inaccesible; reintentar consulta sin fallback al mismo ZIP |

Recibido y aplicado se mantienen separados: el positivo del test tiene aceptación técnica ACCEPTED y aplicación comercial FAILED. Los contextos/registro de fixtures son argumentos sintéticos, no credenciales ni prueba de autenticidad remota. No se afirma disponibilidad de un registro ERP así ni de una consulta autenticada implementada hoy.

## 8. Dependencias ERP — pendientes, con evidencia y siguiente trabajo

No hubo cambios desde d680fa91 hasta la base actual en los caminos auditados `syncInbox.js`, `terminalFiscalAllocationService.js`, `terminalFiscalConfigService.js` y `posSequenceSync.js`. Se revisaron las referencias locales; no se auditó BD desplegada.

| Dependencia | Estado y evidencia ERP | Siguiente trabajo necesario (aparte, tras acuerdo) |
|---|---|---|
| Collection / Advance | Recepción/persistencia original no demostrada. Rutas inspeccionadas syncInbox: transactions7018, cash/movements7258, z-reports7292, inbox/batch9541 e inbox9627; ninguna prueba aportada de canal independiente completo para estos tipos | Identificar productor/receptor y contrato nativo/allocations/heads; diseñar respaldo durable técnico separado de reaplicación comercial y probarlo |
| Wallet independiente | Destino POS /api/sync/operational/events sin receptor equivalente encontrado en el ERP auditado; evento derivado desde venta no acredita fila wallet independiente | Resolver canal/versionado y snapshot histórico/link de moneda/cliente; pruebas de recepción/deduplicación sin duplicar pagos |
| CAS común | Guard compartido para todas las escrituras no demostrado por estos receptores ni por la recepción batch; accepted/application distintos | Inventario completo de escritores, control de revisiones y aceptación atómica; pruebas multiconexión/crash/ACK/takeover antes de habilitar |
| Cuarentena fiscal | releaseTerminalFiscalAllocation:324 marca RELEASED; filtro ACTIVE/PAUSED no lo conserva como intervalo no reutilizable | Diseño de cuarentena completa perdida, independiente de emisión; custodia y bloqueo ante reserva desconocida |
| Reasignación fiscal | validateTerminalFiscalAllocation:174 consulta solapamientos; create:256 valida y luego inserta separado; recomendación no reserva atómicamente | Asignación/validación de no solapamiento en transacción con todos los escritores, propiedad/ámbito/tipo/límites y pruebas de carrera |
| Series internas | Sin mecanismo de exclusividad de recuperación certificado; contadores/sync desde uso conocido no prueban seguridad tras pérdida | Reserva/avance exclusivo durable con precondiciones y resultado idempotente, mismo commit correspondiente; no zReports.length+1 |
| Registro raíz/archivo | No existe evidencia aportada de la nueva aceptación técnica, registro y custodia descritos arriba | Acordar identidades/perfiles/retención/fuente autenticada, luego diseñar almacenamiento/consulta y demostrar durabilidad; no inventar una ruta disponible |

## Reproducir

```sh
node docs/pos-pending-day-recovery/pos-j3-evidence/docs/pos-recovery-j3/verify-contract.mjs
python3 docs/pos-pending-day-recovery/pos-j3-evidence/docs/pos-recovery-j3/verify-bytes.py
node docs/pos-pending-day-recovery/verify-j3.mjs
```

Con Node y Python/jsonschema4.25.1, los verificadores ERP anteriores siguen disponibles: verify-fixtures.mjs, verify-schema.py, verify-r4.py y verify-j2.mjs. No requieren servidor o DB. verify-j3 contrasta los ocho bindings, rechaza campos/fechas/reservas/envolturas incoherentes, prueba commandId divergente incluso rehasheado y errores de registro/archivo/raíz; no certifica reglas de negocio pendientes. Los tests de días imposibles y domain/modo reproducen explícitamente las limitaciones del verificador POS recibido y comprueban la restricción adicional ERP.

Los ocho acuerdos quedan respondidos; lo aceptado provisionalmente no autoriza implementar. Antes de una implementación deben ratificarse IDs/campos de intención, perfiles semánticos completos, modalidades de numeración, fuente confiable, retención y garantías de todos los productores.
