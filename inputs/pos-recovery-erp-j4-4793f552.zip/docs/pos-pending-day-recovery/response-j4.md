# ERP — respuesta a POS J4, intención v2 y límites de los subperfiles

Entrada: `pos-recovery-j4-bf03edf.zip`; leído primero [POS_RESPONSE_J4.md](pos-j4-evidence/docs/pos-recovery-j4/POS_RESPONSE_J4.md). PR [CLIC-POS #560](https://github.com/fdiazinoa/CLIC-POS/pull/560) consultada: MERGED, head `bf03edf36d6fe4ee99d5a4e153396f52e61715c2`, base develop. Base de esta rama ERP: `origin/clean-erp` en `2a4ccfdd`, que incluye ERP J3 `10eef7a1`.

**Solo revisión documental y pruebas offline. UNAGREED; legacy UNKNOWN, exactZEligible=false, closeAuthorization=NOT_GRANTED.** No se implementaron journal, almacenamiento, endpoints, migraciones, cálculo o cambios de pairing/takeover. No se consultó producción ni se ejecutaron ventas/cierres de prueba. Las restricciones del verificador ERP nuevo son controles de ejemplos documentales, no código operacional ni un nuevo cálculo POS.

## Resultado y diferencias concretas

SHA256SUMS de entrada: PASS. Los cinco comandos indicados pasan: binding v1 (8/46 negativos), bytes v1 (8), semántica v2 (8 ejemplos), negativos POS rehasheados (167) y bytes v2 (8) con conservación de publicados.

**Los hallazgos de binding J3 quedan corregidos en el verificador POS actualizado.** Se reprodujeron contra esa copia, no contra el J3 archivado: fechas imposibles, reserva vacía/blancos, extras en la envoltura, campos asignados dentro de drafts incluso anidados y anclaje con domain/modo incorrectos son rechazados. Fecha bisiesta válida pasa. Cuatro roles históricos conservan números/fechas sin mutación: originalBefore, documentsBefore, walletBefore y linkedDocument. Esto prueba preservación/binding; no certifica semántica completa de esos antecedentes.

**Persisten tres límites comprobados en checkSemantics J4:**

| Caso nuevo, con hashes de artifacts e intención recalculados | Resultado recibido | Regla ERP documental / cambio solicitado POS |
|---|---|---|
| NC con dos cartId distintos, ambos sobre la misma línea original: quantity2+2, remainingRefundQuantity2; importes/pagos ajustados a400 | SEMANTIC_FIXTURE_VALID_NOT_AUTHORIZED | Rechazar por límite **agregado por línea original**, no comprobar cada línea por separado. Negativo REFUND_AGGREGATE_LIMIT; positivo1+1 contra2. Conversiones UOM requieren perfil explícito antes de comparar cantidades |
| SALE TRACKED, una línea vendida y delta de inventario+999 con cartId/producto/almacén/unidad reconocidos | SEMANTIC_FIXTURE_VALID_NOT_AUTHORIZED | No acredita signo/cantidad/expansión/cobertura ni unicidad del plan. ERP bloquea TRACKED como UNSUPPORTED_TRACKED_INVENTORY_PROFILE hasta perfil completo y evidencia; no inventa una fórmula delta=-quantity universal |
| Venta del subperfil DOP/tasa1, amount110/applied100/change10 y changeCurrencyCode=USD | SEMANTIC_FIXTURE_VALID_NOT_AUTHORIZED | No admitir cambio extranjero dentro de este subperfil simple. ERP exige DOP explícito cuando hay cambio positivo; ausente es desconocido, no default. Negativo UNSUPPORTED_CHANGE_CURRENCY; positivo con cambio DOP |

Son discrepancias entre el alcance semántico descrito y lo que el modelo comprueba, aunque su resultado ya diga NOT_AUTHORIZED. No se afirma que haya un fallo de producción. Corregirlas/documentar su bloqueo antes de llamar validado al subperfil correspondiente. No se cambian originales ni signos/importes al importar.

El nuevo [verify-j4.mjs](verify-j4.mjs) ejecuta **157 negativos independientes**, incluyendo estas copias rehasheadas;16 bindings v1/v2 y cuatro positivos históricos. Conserva ocho ejemplos v2 originales como ejemplos limitados. También comprueba replay de IDs/resultado, rechazo de cambio con commandId reutilizado y una declaración coherente de dos series que debe fallar por variante no acordada.

## 1. Intención/IDs/perfiles — v2 aceptada provisionalmente; semántica requiere cambios

Los ocho comandos v2 tienen executionContext obligatorio, domain/version2 y perfiles `.j4`; los roles se ligan por hash y no pueden omitirse. CLOSE_SET añade closeControl exacto `{closeId,closeEventId,nextOpenSetId}`; los tres UUID son distintos y nextOpenSetId difiere del actual. La reutilización del cierre previo se rechaza. Cambiar cualquiera de los tres IDs cambia intentHash. No se autoriza reutilizar identidades ya existentes en otros controles: exige registro/índices durables, aún pendientes.

**Ratificación provisional del momento:** IDs técnicos y contenido se congelan antes de intentHash. Preparar IDs no crea Z, no consume número ni abre/activa conjunto. El futuro commit debe revalidar corte/series y guardar resultado/artefactos/membresía/control/outbox/siguiente conjunto conjuntamente. El número y relojes/resultados asignados dentro del commit se conservan una sola vez; no se regeneran en retry. Fallo antes del commit no publica el siguiente conjunto.

El modelo ERP guarda un resultado *sintético* con esos IDs y `committedInTest=false`; replay idéntico devuelve ese mismo objeto. Cambiar closeControl conservando commandId produce COMMAND_ID_CONFLICT aunque los hashes sean correctos. No ejecuta persistencia ni prueba atomicidad. Identidad de comando y aceptación de cierre continúan separadas: auth fresca antes del lookup; aceptación existente estable antes del CAS para un cierre nuevo. Datos de intento HTTP/activation/impresión no se añaden a intentHash.

**V1 se conserva sin traducir.** Sus bytes, roles y hashes no cambian. Se prueba que pasar v2 al verificador v1 se rechaza; no hay adaptación implícita a un objeto anteriormente aprobado. La corrección del verificador v1 tampoco certifica drafts históricos mínimos como ejecutables.

El veto recursivo de campos asignados se acepta solo para el draft nuevo definido por ese perfil. No depurar JSON recuperado, snapshots históricos o metadatos legítimos para hacerlo pasar. Un homónimo legítimo exige ruta/perfil versionado, no excepción silenciosa. Los tres límites semánticos anteriores deben corregirse o bloquearse explícitamente.

### Matriz expectedSeries: posición ERP

Se acepta provisionalmente la matriz **para estas variantes candidatas**, no como descripción universal de la numeración actual:

| Comando | Presencia propuesta | Purpose / condición |
|---|---|---|
| SALE_CREATE | Obligatoria, exactamente1 | TICKET |
| REFUND_CREATE | Obligatoria, exactamente1 | CREDIT_NOTE |
| COLLECTION_CREATE | Obligatoria, exactamente1 | PAYMENT_IN |
| BOOKING_ADVANCE_CREATE | Opcional explícita0/1 | NONE con razón/resolver comprobables, o ADVANCE_RECEIPT; allocations vacías y appliedAmountBase0 |
| CASH_CREATE | Prohibida,0 | No emisión documental en esta variante |
| WALLET_POST | Prohibida,0 | Head y vínculo resueltos; otra variante exige perfil propio |
| FISCAL_REVISION | Prohibida,0 | Observación/revisión del mismo documento, no nueva emisión |
| CLOSE_SET | Obligatoria, exactamente1 | Z_REPORT; sin contador derivado del número de reportes |

Para NUMBERED, cada expectedSeries debe corresponder exactamente a su allocation: ámbito canónico/propietario, ID de serie/reserva, revisión, next, purpose y límites. `start<=next<=end` es condición para consumir el siguiente número; `advance='1'` solo describe este candidato. Si se consume end, el cursor posterior end+1 debe representar agotamiento, no permiso de emitir fuera del intervalo. Revisión y cursor se actualizan con resultado en la transacción futura; no se retrocede ni se usa max conocido como prueba de disponibilidad.

`reservationId=null` significa **modalidad INTERNAL_EXCLUSIVE declarada**, cuya exclusividad/propiedad/revisión/límites deben probarse en ERP. No significa SAFE, reserva perdida, dato desconocido ni autorización por ausencia. String no vacío corresponde a RESERVED y exige reserva realmente emitida al ámbito; no basta autodeclarar el propietario. ResolverVersion/reason son referencias de intención, no evidencia de que se consultó una política confiable. No normalizar IDs recortando espacios silenciosamente; su formato definitivo debe acordarse.

**Límite una serie:** se ratifica como barrera del subperfil v2. Una operación que necesite ticket y NCF u otras dos reservas queda UNSUPPORTED_PROFILE/MULTIPLE_SERIES_UNAGREED. No dividirla en dos comandos para eludir el límite, ni consumir una sola mitad. Ampliarla requiere perfil/versionado completo con purposes y relaciones, conjuntos exactos de reservas, avances/resultados por serie, orden de bloqueo, control conjunto de precondiciones y pruebas de crash/idempotencia. No modifica la operación POS vigente; solo limita lo certificable por el contrato candidato.

## 2. Control/retención — acuerdo técnico provisional; ERP/operación pendientes

Se mantiene Z/control fuera del prefijo que sella, sin circularidad y sin purga por ACK. La posición POS sobre retención coincide con la propuesta ERP J3:

- Snapshots/páginas/cursors y recibos de importación pueden expirar según política;24h/7d siguen propuestas, no SLA desplegado.
- Comandos, aceptaciones, originales/revisiones, configuración/declaración/Z/sello y tombstones tienen ciclos independientes. No borrar identidad/digest de deduplicación por TTL de descarga.
- Lookup debe cubrir activo, archivo y tombstone coherentemente antes de recrear. Tombstone puede reconocer identidad/conflicto, pero no sustituye artefactos para restaurar; archivo ausente produce ARCHIVE_UNAVAILABLE.
- Si se exige borrar también claves de deduplicación, se necesita antes un corte de protocolo que rechace irrevocablemente las épocas/IDs antiguos; sin prueba no se aprueba GC. Generar UUID nuevo no legitima reemitir el negocio anterior.

ERP/operación deben decidir custodio, plazos por clase, volumen/costo, copias/restauración, RPO/RTO, disponibilidad/acceso y bajas tenant/terminal. ERP debe demostrar transacción/archivo/índices/consistencia; POS debe demostrar commit local por backend después de acuerdo. No se infiere ninguna obligación legal ni almacenamiento ya implementado.

## 3. acceptanceDigest — aceptado provisionalmente; mecanismo no demostrado

J2 permanece intacto: digest estable y recomputado, unicidad independiente de closeId y closeEventId por ámbito, lookup tras auth y antes del CAS de nuevo cierre. FAILED comercial no invalida identidad ACCEPTED técnica ni habilita reaplicación desde POS. Reintento de comando y reintento de aceptación son niveles distintos. Faltan índices/guard/transacción, todos los escritores, ACK/crash/archivo y continuidad de la deduplicación; preparar closeControl no demuestra esos mecanismos.

## 4. Nombres de corte — requiere futura versión explícita

R4 conserva validationStage y nombres actuales. proposedThrough en progreso y sealedThrough solo final siguen pendientes de versión discriminada/migración/rechazo de mezclas. J4 no los cambia. Un prefijo recibido sin sello final no permite afirmar cola vacía ni certificar la jornada de una base perdida.

## 5. UTF-16/JCS — correcciones conservadas, generalidad pendiente

Sin discrepancia nueva respecto de ERP J2. Se conservan comparador UTF-16, emisión directa de pares numéricos y todos los hashes históricos. Los vectores publicados se comprueban byte por byte. Parser raw que detecte claves duplicadas, Unicode/números límite y corpus general aún no están certificados. Los helpers de fixtures no son bibliotecas de producción.

## 6. semantic-rules/captura/orden/configuración — separar lo ejecutable de lo no demostrado

La separación A(binding), B(subperfil semántico) y C(origen/atomicidad/aceptación) es correcta. El estado NOT_AUTHORIZED debe mantenerse en todas las salidas. Se propone ajustar la lectura de semantic-rules.json:

| Grupo de reglas | Qué demuestra el modelo | Estado ERP / pendiente |
|---|---|---|
| BINDING, CONTROL_IDS | Rechazos J3, roles/contexto y vínculo de IDs | Corregidos/provisionales; commit y unicidad durable no demostrados |
| NUMBERING, HEADS | Relaciones declaradas/forma/hash de snapshots y heads | Provisionales; propiedad real, archivo confiable y CAS pendientes |
| SALE_SIMPLE, REFUND | Aritmética sintética DOP y relaciones seleccionadas | Requiere bloquear cambio extranjero y límite NC agregado; no oráculo nativo |
| Inventario TRACKED | Reconoce referencias y delta finito no cero | No demuestra cobertura/dirección/cantidad/UOM/receta. Añadir estado propio BLOCK_UNTIL_NATIVE_EVIDENCE o perfil cerrado completo; ERP lo bloquea en su guard documental |
| COLLECTION, ADVANCE | Coherencia simple de allocations/cliente/deuda/booking declarados | Subperfil limitado. Precisión/FX/canales nativos y heads confiables pendientes; anticipo con allocations sigue fuera |
| WALLET, CASH, FISCAL | Signo/link/head, forma/motivo y whitelist fiscal respectivamente | No prueba saldo cash disponible, autenticidad de proveedor/resultado ni tipos completos de patch; creación wallet/link ausente/cashback fuera |
| CONFIG, DECLARATION |14 bloques, estados de presencia, selección/orden, parte de declaración/denominaciones | Tipos completos/cobertura de lecturas/políticas/monedas/métodos/renderer pendientes |
| SALE_COMPLEX, REPORT_PRINT | Requisitos escritos | Bloqueados por evidencia nativa |
| ROOT_ARCHIVE, ATOMICITY | Requisitos escritos y modelos sintéticos previos | Bloqueados por evidencia ERP/runtime |

No basta `VALUE` con cualquier payload: se requieren tipos de cada bloque y valores efectivos/versiones/resolvers. J4 reconoce que no lo valida por completo; por tanto `VALUE:null`, monedas/métodos incompletos, `sourceVersions` sin hashes o campos de impacto no clasificados no son evidencia de cobertura. El fixture CLOSE_SET usa DECLARED_NOT_PROVEN y readCoverage NOT_PROVEN, con resumeAnchor ausente: es una prueba de estructura, no un cierre respaldado. No convertirlo en caso exacto por pasar el verificador.

Captura debe conservar los originales y campos desconocidos observados, con validación pendiente; no reinterpretarlos por defaults vigentes. Faltan schemas de canal y precisión/rounding/versiones, variantes crédito/FX/impuestos/descuentos/modifiers/recetas, saldos/planes históricos, políticas de declaración por método/moneda y dependencias instrumentadas. La tolerancia1e-8 es del ejemplo, no política monetaria acordada. Nuevos campos con impacto exigen perfil o bloqueo.

Para impresión siguen pendientes Z/anexos completos, activos/layout/renderer/versiones, información pública/locale/opciones, snapshot de configuración y pruebas contra salida nativa vigente. Ausencias de openedAt/declaración/annex no se reconstruyen. No se ejecutó cálculo alternativo, impresión, correo ni proveedor fiscal en esta revisión.

## 7. Registro confiable/archivo — aceptado provisionalmente; fuente y mecanismos pendientes

Se acepta la posición POS sobre el registro propuesto ERP J3: identidad/revisión/ámbito/coordenadas/antecedentes, digests y artefactos completos, aceptación técnica separada de aplicación, retención y localizador administrado. Se conserva pos.journal.resume.v1 en configuration.resumeAnchor. Ni el request ni el ZIP proporcionan la raíz de confianza.

ERP debe obtener esa raíz mediante auth vigente y lectura de un registro durable independiente; comparar registryRevision y recomputar archivo/artefactos/cadena/selección contra la raíz guardada. Aceptación técnica ACCEPTED con aplicación FAILED puede ser referencia de contenido, pero FAILED sigue visible y no autoriza reaplicar. La corrección POS de domain/modo es necesaria, no suficiente para acreditar archivo o autenticidad.

Los errores lógicos propuestos se mantienen: AUTH_REQUIRED, ROOT_SCOPE, UNKNOWN_ROOT, ROOT_NOT_ACCEPTED, ROOT_REVISION_CHANGED, ARCHIVE_UNAVAILABLE, ARCHIVE_CORRUPT, ROOT_BINDING, ANCHOR_DOMAIN, ANCHOR_MODE y ROOT_UNAVAILABLE. No tienen rutas o HTTP desplegados afirmados aquí. Si falla la fuente, se reintenta lectura consistente o se conserva diagnóstico; nunca fallback al digest del mismo paquete. Tombstone no permite reconstruir artefactos perdidos.

SAME_EPOCH_SUFFIX requiere evidencia de continuidad física/durable de la base y su contador; comparar UUID no la prueba. NEW_EPOCH no elimina incertidumbre de la cola previa. No se aportó evidencia nueva de registro/consulta/archivo ERP implementados. Se reutilizará pairing/takeover existente, sin rediseñarlo.

## 8. Canales/CAS/reservas — pendientes sin evidencia nueva

Se mantienen las dependencias detalladas en [response-j3.md](response-j3.md), no una auditoría nueva de producción:

| Dependencia | Estado / evidencia conocida | Siguiente trabajo requerido |
|---|---|---|
| Collection/Advance | Sin canal original completo demostrado en los receptores ERP auditados | Contrato de productor/receptor/allocations/heads y persistencia técnica sin reaplicación |
| Wallet independiente | Destino /api/sync/operational/events sin receptor equivalente encontrado; derivado de venta no equivale a fila independiente | Canal y snapshot/link histórico moneda/cliente, deduplicación sin duplicar pagos |
| CAS común | No probado en todos los escritores directos/batch/RPC/admin/series/configuración | Inventario de escritores, exclusión/revisiones y pruebas multiconexión/crash/ACK/takeover |
| Cuarentena fiscal | release no conserva intervalo como no reutilizable | Apartar intervalo completo perdido sin declararlo emitido; bloquear reserva desconocida |
| Reasignación | SELECT de solapamientos antes de INSERT no acredita atomicidad | Reservas no solapadas, propietario/ámbito/tipo/límites y avance en transacción con todos los escritores |
| Series internas | INTERNAL_EXCLUSIVE es declaración candidata, no mecanismo certificado | Asignación/avance exclusivo durable ligado a resultado idempotente; no zReports.length+1 |
| Archivo/raíz/retención | Modelos y acuerdos provisionales | Implementación aparte solo después de ratificar registro, custodia, deduplicación y evidencia exigida |

No se autoriza implementar porque las partes coincidan provisionalmente. La siguiente entrega POS debe corregir el límite NC agregado, cerrar/bloquear inventario TRACKED y cambio fuera del subperfil, y precisar evidencia/variantes todavía no soportadas. ERP/operación mantienen las decisiones y pruebas que les corresponden.

## Reproducibilidad

POS recibido, sin editar:

```sh
node docs/pos-pending-day-recovery/pos-j4-evidence/docs/pos-recovery-j3/verify-contract.mjs
python3 docs/pos-pending-day-recovery/pos-j4-evidence/docs/pos-recovery-j3/verify-bytes.py
node docs/pos-pending-day-recovery/pos-j4-evidence/docs/pos-recovery-j4/verify-semantics.mjs
node docs/pos-pending-day-recovery/pos-j4-evidence/docs/pos-recovery-j4/verify-negatives.mjs
python3 docs/pos-pending-day-recovery/pos-j4-evidence/docs/pos-recovery-j4/verify-bytes.py
```

Revisión ERP nueva:

```sh
node docs/pos-pending-day-recovery/verify-j4.mjs
```

Se mantienen verify-fixtures.mjs, verify-schema.py (jsonschema4.25.1), verify-r4.py, verify-j2.mjs y verify-j3.mjs con sus entradas históricas. verify-j3 reproduce limitaciones del J3 archivado; **verify-j4 evalúa el POS actualizado**. SHA256SUMS y published-vectors.sha256.json se validan; los siete archivos históricos ERP continúan byte-idénticos. No se recalculan hashes publicados para conseguir PASS.
