# ERP R4 — respuesta a los 11 puntos POS

> Revisión posterior R4: [invariantes conjuntas y una revisión por operación](r4-invariants-response.md). Esta precisión sustituye la unicidad por terna y las verificaciones aisladas del candidato; sigue siendo propuesta UNAGREED.

Fecha: 2026-09-06. Base ERP `69198aa8` de `origin/clean-erp`. Entrada: `pos-recovery-r3-response-c266200.zip`, POS fuente `2e200a2ff7854cbb08fa8218cffb09dbdb7bdf57`. [Respuesta recibida](pos-r3-evidence/docs/pos-recovery-r3/RESPONSE.md), [definiciones](pos-r3-evidence/docs/pos-recovery-r3/native-definitions.ts.txt), [índice de campos](pos-r3-evidence/docs/pos-recovery-r3/native-fields.json), [pares de serialización](pos-r3-evidence/docs/pos-recovery-r3/serialization-pairs.json).

**Incorporación documental; acuerdo bilateral final pendiente. Legacy UNKNOWN, exactZEligible=false y closeAuthorization=NOT_GRANTED.** No se implementaron endpoints, persistencia, migraciones ni cambios de cálculo. Los scripts POS se archivan como evidencia recibida; ERP no los ejecutó ni accedió al repositorio POS. Los ejemplos son sintéticos y la comprobación de sus archivos no acredita tráfico desplegado, restauración o atomicidad.

Esta respuesta sustituye las preguntas R3 en los puntos respaldados por evidencia. Los [perfiles candidate-v2](original-profiles.schema.json) son mínimos operacionales parciales, separados de los envelopes de [descarga/importación](contract.schema.json) y del [protocolo de cierre](closure-protocol.schema.json). Aprobar una forma no activa ninguna de esas capacidades.

## 1. Definiciones por tipo, campos y versiones

Incorporamos las 20 definiciones textuales y su índice, conservando herencia/opcionalidad/uniones como evidencia. Corregimos Transaction.terminalId opcional, status obligatorio con PENDING/COMPLETED/REFUNDED/PARTIAL_REFUND y documentType opcional. No hay default SALE cuando falta clasificación; documentType puede contener VOID en la unión, pero Transaction.status no. Payment.method usa los nueve valores exportados, sin convertir desconocidos a CASH. CartItem.id es producto; cartId es renglón, incluso para productos repetidos. name y userName se conservan y se exigen en el perfil parcial de fidelidad, aunque su ausencia no impida toda suma de efectivo.

Collection.seriesId/seriesNumber pasan a opcionales. Los importes FX/recibido/aplicado/no aplicado requeridos en este candidato son deliberadamente más estrictos que los opcionales nativos; nunca se rellenan con totalAmount. CashMovement no exige terminalId/currencyCode para aceptar su forma; ámbito y moneda histórica comprobables siguen siendo precondiciones de cualquier cálculo exacto. ZReport exige baseCurrency y transactionCount; notes admite vacío. Todas las secciones recibidas, incluidas stats, denominationBreakdown, closeTaxSummary, paymentMethodSummary, reportDetails y declaraciones, se conservan por additionalProperties; ello no certifica su forma ni la impresión completa.

No exigimos los maestros Product eliminados por el emisor para copiar un DTO operacional. appliedTaxIds no acredita tasas históricas. TypeScript sin strictNullChecks/exactOptionalPropertyTypes no es validador runtime: null, ausente y cero siguen distintos. El esquema futuro puede rechazarlos; el envelope permite archivarlos sin alterarlos y reportar carencias. candidate-v2 es versión del perfil ERP, **no versión nativa**. originalSchemaVersion/originalRevision legacy permanecen UNKNOWN; schemaVersion/aggregateVersion=1 del outbox no las reemplazan.

Pendiente: versión nativa acordada por tipo/canal, perfiles completos de cálculo y de cada sección impresa, política de null/aliases y una muestra real autorizada por canal. Los 13 objetos aportados pasan el perfil parcial; también pasa CASH_REFUND_UNVERIFIED, lo que demuestra que el schema no valida semántica monetaria.

## 2. Objeto local, envío directo, batch y receptor ERP

Aceptamos la distinción demostrada. Directo elimina definiciones Product y proyecta pagos mediante allowlist; batch puede conservar images/gatewayRawResponse. Se preservan los originales de ambos canales tal como se recibieron; no se completa directo desde maestros actuales ni se aplica su blocklist a batch. PAYMENT_POSTED es evidencia adicional del mismo pago, nunca otro ingreso. Root currency_code puede ser moneda de liquidación, no baseCurrency.

En ERP, `server/routes/syncInbox.js` contiene `/transactions` (7018), `/cash/movements` (7258), `/z-reports` (7292), `/inbox/batch` (9541) y `/inbox` (9627); deriveTransactionEvents (3931) y buildPosEventEnvelope (2908) preservan objetos con contexto/proyecciones adicionales. El batch usa `erp_sync_receive_inbox_batch`; los detalles y límites de conservación están en [review-r3.md](review-r3.md) y en el catálogo de solo lectura ya capturado. Ese receptor no proporciona un historial común append-only ni convierte aggregateVersion en revisión verificada. No reenviar eventos financieros para completar metadata.

**Discrepancia wallet:** el par WALLET_PAYMENT apunta a `/api/sync/operational/events`. La búsqueda en `server/` de esta base no encuentra ese receptor. deriveTransactionEvents sí deriva WALLET_MOVEMENT_POSTED desde venta, pero no es prueba de ingestión de la fila WalletTransaction independiente ni de su historial. Reconocemos el constructor POS, dejamos recepción/persistencia independientes NO_DEMONSTRATED y pedimos identificar receptor desplegado, versión y cuerpo recibido. Collection/Advance conservan httpBody=null: no inventamos emisor ni cobertura remota.

El remapeo de terminal/dispositivo con credenciales sintéticas ilustra transporte, no prueba ámbito histórico. Recovery debe resolver tenant/company/store/terminal autenticados; local_terminal_id/localTerminalId solo son procedencia. Una contradicción entre columna/payload/alias exige SCOPE_UNRESOLVED.

## 3. Timestamps y conservación

Ratificamos como propuesta futura ISO-8601 con zona y precisión máxima de milisegundos; el perfil comprueba zona y hasta tres decimales. Date/string normalizados, epoch en milisegundos, null/ausente convertidos a reloj del emisor e inválido convertido a null están archivados. Las últimas conversiones describen pérdida histórica, nunca reglas de recuperación. No se cambia fecha por hora actual, no se adivinan segundos/milisegundos y no se corrige reloj atrasado. Allocation/CashMovement conservan el texto recibido; operación y recepción son campos diferentes.

Precisión de hashes: JCS calcula sobre el **valor JSON canónico**, no conserva espacios, orden de claves ni los bytes HTTP originales. JSONB no permite recuperar esos bytes. Conservamos cadenas de fecha, números, ausencias y null del original; no se hidrata Date sobre el objeto hasheado. Si se necesitan bytes de transporte exactos habrá que acordar un archivo raw separado con digest propio; no lo afirmamos disponible hoy.

## 4. Devolución y cálculo actual

Aceptamos como representación observada NC nueva Transaction REFUND/REFUNDED, cantidades/total positivos, ID propio y vínculo al original. STORE_CREDIT/CARD y CARD_VOID como NC con gatewayTransactionType=VOID están respaldados por los ejemplos. La venta cerrada referenciada es dependencia read-only fuera de sumas; si realmente pertenece al conjunto se incluye por su propia membresía, sin restar dos veces por status y NC.

F04 CASH sigue dando **1050 diagnóstico** con fondo1000 y nota positiva50; no se fuerza950, no se cambia método/signo y no se declara reembolso CASH validado. Reembolso efectivo/multimoneda y STORE_CREDIT frente a deuda pendiente siguen pendientes. F01 mantiene efectivo físico **USD10 y DOP−50**, separado del equivalente convertido **DOP550**; no implica DOP550 físicos. Ningún importe reconstruye la declaración física perdida.

## 5. Mutaciones de venta original, VOID y fiscal

Archivamos before/after de venta total550 intacto y status PARTIAL_REFUND, relatedTransactions, updatedAt/syncStatus; también before/after fiscal al mismo ID. Son evidencia de mutación local/serialización potencial, no revisión remota durable ni canal FiscalUpdate probado. No ejecutar localRefundPersistence, reemitir SALE ni llamar proveedor al importar.

VOID comercial independiente sigue sin shape/tombstone/protocolo universal; su perfil queda sin candidato certificado. El VOID de tarjeta observado no permite convertir toda anulación comercial a NC. Pendiente acordar cuáles mutaciones requieren revisión operacional, su identidad técnica independiente del eventId financiero y almacenamiento inmutable. Un cambio de contenido a igual ID/revisión/hash esperado debe ser conflicto, incluso si hoy un canal preserva una copia antigua.

## 6. Abonos, anticipo y wallet

Nuevo Advance = Collection + bookingActivityId, opportunityId opcional; no appointmentId ni depósito acumulado de agenda como original alternativo. Fixture con allocations30+50, recibido100/aplicado80/no aplicado20 conserva IDs POS y requiere las dos dependencias históricas read-only. Importar no reaplica allocations ni cambia deuda. Los ejemplos legacy F02/F04 originales permanecen intactos y sus carencias se vuelven a evaluar; no se maquillan con campos nuevos.

WalletTransaction usa walletId/type/amount firmado/timestamp y referenceId opcional. PAYMENT negativo no se transforma a dirección artificial; referencia puede ser displayId, aun si source_transaction_id lo copia. Moneda/cliente necesitan snapshot histórico de wallet más vínculo verificable. Su ausencia significa UNKNOWN. No consultar wallet vigente para fabricar historia y no sumar STORE_CREDIT/wallet como dos cobros. Pendientes el vínculo histórico y el receptor independiente señalado en punto2.

## 7. openedAt en jornada de solo abonos

Ratificamos: solo se conserva openedAt exacto si existe en Z persistido, aun cuando originalmente se generó como fallback al cerrar. Si se perdió antes de persistencia/envío, no se reconstruye con Collection.date ni mínimo timestamp. El futuro reloj de cierre no equivale al histórico. Persistencia de apertura durable será trabajo aparte; tampoco se corrige aquí la omisión de abonos del cálculo actual.

## 8. Manifiesto de cierre e identidad

Adoptamos **para revisión** pos.close-manifest.v1 en `$defs/CloseManifest` del esquema separado. SALE/CREDIT_NOTE del envelope se mapean a TRANSACTION, con commercialType TICKET/REFUND comprobado; sin clasificación se bloquea exactitud. ADVANCE se identifica como COLLECTION con tipo comercial ADVANCE: la misma Collection no aparece dos veces. CashMovement y Wallet conservan tipos propios; PAYMENT_REFERENCE no es miembro adicional. VOID/FISCAL_UPDATE sin protocolo acordado no se promueven a miembros inventados. Dependencias read-only están separadas y no suman.

Propuesta de hashes diferenciados: `Record.hash` sigue siendo el hash del snapshot congelado incluyendo receipt/application; miembro usa **originalContentHash** (renombre explícito del ambiguo hash POS); reportHash cubre Z original; configurationHash y declarationHash requieren los valores históricos, no solo sus digests. originalContentHash propone JCS de `{scope,storageEpoch,openSetId,sequence,kind,originalId,revision,original}` con original inmutable y sin receipt/application del envelope. Incluye cualquier campo efectivamente presente en original: no se eliminan syncStatus u otros campos silenciosamente. Una futura proyección por tipo requiere versión y acuerdo; no está certificada aquí. La cadena de checkpoints necesita especificación criptográfica y vectores bilaterales aún pendientes.

Orden candidato de arrays: `(kind,originalId,revision)` lexicográfico de cadenas por unidades UTF-16, identidades únicas y sin intersección miembros/dependencias. JCS no ordena arrays automáticamente. previousCloseId=null solo con PROVEN_FIRST; EXPLICIT_PREVIOUS requiere UUID. Legacy usa su envelope UNKNOWN separado. closeId y closeEventId son UUID distintos y persistidos. El verificador añade reglas semánticas que JSON Schema no expresa por sí solo.

Transacción local requerida: Z+manifiesto+membresía+avance de reserva+evento técnico y archivo/marcas sin perder original. Antes de commit, nada; después, reintento con mismos IDs/hash. SQLite de ventas no demuestra este commit de cierre; IndexedDB/LAN requieren evidencia equivalente. Los valores de hash/UUID del nuevo fixture de protocolo son **marcadores sintéticos de forma**, no un sello calculado ni prueba de cierre. Atomicidad local, preimagen final/hashes/cálculo/configuración y compatibilidad de cada backend siguen pendientes.

## 9. Época, conjunto y checkpoint sellado

Aceptamos UUID storageEpoch al crear base y openSetId antes de operar, sin cambiarlos por simple rebind. Pérdida crea época nueva; nunca recicla contador ni certifica la anterior. Alta/mutación comparte commit con documento/revisión/secuencia/outbox; varios eventos financieros pueden representar una posición operacional. Secuencias wire son strings decimales, no Number inseguro.

Aclaración ERP propuesta: **sello OPEN_SET**, no cierre obligatorio de toda storageEpoch. Congela escrituras al conjunto; nuevas operaciones usan otro openSetId en la misma base/época y continúa secuencia de época. Un sello de época completa sería otra operación por acordar. El candidato incluye ambos IDs; checkpoints son prefijos de época hasta el límite del conjunto. Solo un sello final probado, cadena/miembros completos y todos los productores excluidos de escritura demostrarían cola vacía. El esquema no prueba esas condiciones y mantiene exactZEligible=false.

Sin finalSeal, unknownTailPossible=true incluso con contiguousReceived=highestCommitted=highestReceived. El sustituto no puede sellar retroactivamente una cola perdida. Se validan límites/gaps y coherencia de sello en ejemplos; faltan algoritmo de cadena, recepción/retención del sello, política de revisiones y pruebas de crashes por backend. No confundir estos tests de especificación con pruebas distribuidas.

## 10. CAS final, idempotencia y escritores

Ratificamos el orden propuesto: auth fresca; buscar identidad ya aceptada; mismo ID/hash devuelve estado persistido aun RECEIVED/FAILED y aunque el corte haya avanzado, sin repetir aplicación; otro hash409. Legacy recibido se reconoce sin autorización exacta. **Solo para cierre nuevo** se comparan revisiones de scope/originals/membership/close/series/configuration, configurationHash, epoch/sello y activationId bajo exclusión compartida de terminal/series. Cualquier diferencia409 CUT_CHANGED antes de aceptar/aplicar/consumir. Persistir aceptación+manifiesto+IDs/evento en una transacción; aplicación comercial posterior independiente. Otra activation no es aceptación Z. Offline queda provisional.

Escritores ERP que deben participar: receptores directos citados, inbox genérico, RPC batch, escrituras de originales/revisiones futuras, posEventApplier cuando altere contenido/serie, posSequenceSync, asignación/configuración fiscal, settings administrativos de ámbito/series/configuración, marketplace si comparte ámbito, reintentos/backfills/importadores autorizados que modifiquen contenido. POS añade todos los productores enumerados en RESPONSE, incluido LAN. Este inventario es condición de diseño: el guard común no existe ni se prueba exhaustividad externa. Un escritor incompatible mantiene exactitud bloqueada. Estado exclusivamente receipt/application se observa aparte y no modifica originalContentHash; si es precondición, se revalida explícitamente.

Se reutilizan autorización canónica y takeover vigentes; no se crea otro pairing. Se necesitan pruebas de dos conexiones, aceptación versus escritor tardío, reserva concurrente, ACK perdido, crash y takeover con el mismo guard. Los seis casos ejecutables entregados solo comprueban orden de decisiones, no esas garantías.

Materialización/retención: seguimos proponiendo una captura REPEATABLE READ de registros+inventario+estados+series, páginas persistidas estables, TTL snapshot24h, recibos/idempotencia/tombstone7d, originales durables sin purga por ACK. **No son configuración desplegada ni SLA acordado.** Faltan volumen, límites y política de archivo/retención con negocio. Se conserva la separación download/receipt/status frente a activation/aceptación.

## 11. Reserva fiscal perdida y numeración interna

Ratificamos cuarentena administrativa **no reutilizable del intervalo completo perdido**, sin afirmar que todos sus números fueron emitidos. Reserva desconocida bloquea la serie. Nuevo bloque exige ámbito/tipo correctos y no solapamiento probado atómicamente contra otras reservas; nunca end+1 o next remoto como prueba. Importar existentes no pide bloque ni consume números.

Operaciones ERP existentes identificadas: `server/routes/settings.js:9891` creación, `:9911` recomendación, `:9932` actualización y `:9947` release; `server/services/terminalFiscalAllocationService.js:174` valida solapamientos ACTIVE/PAUSED mediante SELECT y `:256` creación hace INSERT posterior separado. Recomendación tampoco reserva atómicamente. `:324` release marca RELEASED, que queda fuera del filtro ACTIVE/PAUSED de `:86`: **release no es cuarentena no reutilizable**. La migración `20260511103000_terminal_fiscal_allocations.sql` aporta índice de búsqueda, no restricción de exclusión de intervalos. `terminalFiscalConfigService.js:227` también puede insertar asignaciones y debe participar del futuro control. No encontramos en estos caminos una operación validada de cuarentena/reasignación transaccional; no afirmamos garantía de toda base desplegada sin auditoría adicional.

Por tanto la reanudación de numeración queda BLOQUEADA en este contrato, pendiente de diseñar/validar ese mecanismo aparte y un avance exclusivo para series internas sin reservas. No se ejecutó ninguna de las operaciones mencionadas. No se usa zReports.length+1 ni max conocido para resolver cola perdida.

## Artefactos y acuerdos pendientes

- [contract.schema.json](contract.schema.json), [fixtures.json](fixtures.json): copia/importación, F01 físico versus convertido, legacy UNKNOWN; hashes actualizados solo por cambio de metadatos de validación, originales intactos.
- [original-profiles.json](original-profiles.json), [original-profiles.schema.json](original-profiles.schema.json), [original-validation-results.json](original-validation-results.json): candidate-v2 y diagnóstico legacy.
- [r4-evidence.fixtures.json](r4-evidence.fixtures.json), [r4-validation-results.json](r4-validation-results.json): 13 originales idénticos a evidencia, candidato de manifiesto/checkpoint y seis decisiones de aceptación. El caso14 de mutación y seis timestamps se verifican directamente contra evidencia archivada.
- [verify-fixtures.mjs](verify-fixtures.mjs), [verify-schema.py](verify-schema.py), [verify-r4.py](verify-r4.py): offline; nunca llaman endpoints ni motores POS/ERP. SHA256SUMS de entrada verificado; ningún original o resultado POS se presenta como ejecución propia.

| Acuerdo pendiente | Responsables de contraste | Evidencia requerida antes de implementación |
|---|---|---|
| Esquemas/versiones nativas y perfiles cálculo/impresión | POS + ERP | Muestras reales autorizadas por canal, alias/null, campos históricos y capacidades por sección |
| Recepción de Collection/Advance y wallet independiente | POS + ERP | Emisor/receptor/persistencia verificables; vínculo wallet histórico |
| CASH/multimoneda refund, VOID comercial y fiscal revisions | POS + ERP | Representación y revisión durable, sin corregir cálculo en esta iniciativa |
| Manifiesto/hash/cadena/sello OPEN_SET y revisiones | POS + ERP | Ratificar nombres, preimágenes, orden, vectores y prueba del commit local en cada backend |
| CAS compartido y reservas no reutilizables | ERP + POS | Enumeración completa de escritores y pruebas concurrentes/crash/takeover |
| Materialización, límites, retención y archivo | ERP + operación | Capacidad/volumen, plazos y política aprobados |

No hay recuperabilidad ni cierre exacto certificados. La siguiente entrega debe ratificar estos acuerdos, no habilitar un Z por haber pasado los fixtures.
