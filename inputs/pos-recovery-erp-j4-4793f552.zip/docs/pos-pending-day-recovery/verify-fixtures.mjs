// Offline artifact checks only. No imports from server, no network or database.
// This canonicalizer covers these fixture values, not a production JCS library.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { canonical } from './fixture-canonical.mjs';

const read = name => readFileSync(new URL(name, import.meta.url), 'utf8');
const bundle = JSON.parse(read('fixtures.json'));
const closureProposal = JSON.parse(read('closure-protocol.fixtures.json'));
const posReference = '5993b1fed18c230dde89734e91fa94e0a95ce2bc';
const digestBytes = bytes => createHash('sha256').update(bytes).digest('hex');
const digest = value => digestBytes(canonical(value));
const without = (value, key) => Object.fromEntries(Object.entries(value).filter(([name]) => name !== key));

for (const vector of bundle.canonicalizationVectors) {
    assert.equal(canonical(vector.input), vector.canonicalUtf8);
    assert.equal(Buffer.from(vector.canonicalUtf8).toString('hex'), vector.utf8Hex);
    assert.equal(digestBytes(vector.canonicalUtf8), vector.sha256);
}

function verifyFixture(fixture) {
    const { manifest, records, pages } = fixture;
    assert.equal(manifest.closeAuthorization, 'NOT_GRANTED');
    assert.equal(fixture.expected.closeAuthorization, 'NOT_GRANTED');
    assert.equal(digest(without(manifest, 'etag')), manifest.etag);
    assert.equal(digest(manifest.inventory), manifest.recordsHash);
    assert.equal(manifest.counts.records, records.length);
    const identities = new Set();
    records.forEach((record, ordinal) => {
        assert.equal(digest(without(record, 'hash')), record.hash);
        const key = `${record.kind}:${record.originalId}:${record.originalRevision}`;
        assert(!identities.has(key));
        identities.add(key);
        assert.equal(record.original.id, record.originalId);
        assert.equal(record.originalValidation.status, 'NOT_CERTIFIED');
        assert.equal(record.originalValidation.nativeRecovery, 'BLOCKED_PENDING_AGREEMENT');
        assert.deepEqual(manifest.inventory[ordinal], {
            ordinal, kind: record.kind, originalId: record.originalId,
            originalRevision: record.originalRevision, role: record.role, hash: record.hash,
        });
        record.receipt.forEach(event => assert(record.sourceEventIds.includes(event.sourceEventId)));
    });
    for (const record of records) for (const relation of record.relations) {
        assert(identities.has(`${relation.kind}:${relation.originalId}:${relation.originalRevision}`));
    }
    const downloaded = [];
    pages.forEach((page, index) => {
        assert.equal(digest(without(page, 'pageHash')), page.pageHash);
        assert.equal(page.snapshotId, manifest.snapshotId);
        assert.equal(page.cutRevision, manifest.cut.revision);
        assert.equal(page.firstOrdinal, downloaded.length);
        assert(Buffer.byteLength(JSON.stringify(page)) <= manifest.limits.maxPageBytes);
        assert(page.records.length > 0 && page.records.length <= 200);
        assert.equal(page.nextCursor === null, index === pages.length - 1);
        downloaded.push(...page.records);
    });
    assert.deepEqual(downloaded, records);
    assert.equal(manifest.coverage.exactZEligible, fixture.expected.exactZEligible ?? false);
    if (manifest.coverage.exactZEligible) {
        assert.equal(manifest.boundary.kind, 'EXPLICIT_OPEN_SET');
        assert(manifest.boundary.openSetId);
        assert.equal(manifest.coverage.membershipCoverage, 'EXACT');
        assert.equal(manifest.coverage.unknownTailPossible, false);
        assert.equal(manifest.coverage.knownMissing.knownCount, 0);
        assert.equal(manifest.coverage.knownMissing.unknownCount, false);
        assert(records.every(r => r.originalRevision !== 'UNKNOWN' && r.originalSchemaVersion !== 'UNKNOWN'));
        assert(manifest.series.every(s => s.safety === 'SAFE'));
        assert(manifest.coverage.checkpoints.every(c => c.sealedThrough !== null && c.gaps.length === 0));
        assert(manifest.calculation.declaration);
    }
}
bundle.fixtures.forEach(verifyFixture);
assert.equal(closureProposal.agreementStatus, 'UNAGREED');
verifyFixture(closureProposal.candidateFixture);
assert([...bundle.fixtures, closureProposal.candidateFixture].every(f => !f.manifest.coverage.exactZEligible));
assert.equal(bundle.statusExample.closeAuthorization, 'NOT_GRANTED');
assert(!('activationAllowed' in bundle.statusExample));
assert(!('activationRequestExample' in bundle));
assert(!('activationResponseExample' in bundle));

const [usd, collections, ackLost] = bundle.fixtures;
assert.equal(read('fixture-record.canonical.json'), canonical(usd.records[0]));
const sale = usd.records.find(r => r.kind === 'SALE').original;
const payment = sale.payments[0];
assert.equal(payment.amountOriginal * payment.exchangeRate, 600);
assert.equal(payment.amount - payment.changeAmount, sale.total);
assert.equal(payment.appliedAmount, 550);
function verifyPhysicalVsConverted(fixture) {
    assert.deepEqual(fixture.expected.physicalCashMovementByCurrency, { USD: '10', DOP: '-50' });
    const physical = fixture.manifest.totals.filter(t => t.measure === 'PHYSICAL_CASH_NET');
    assert(physical.every(t => t.baseCurrencyCode === null));
    assert.deepEqual(Object.fromEntries(physical.map(t => [t.currencyCode, t.amount])), { USD: '10', DOP: '-50' });
    const converted = fixture.manifest.totals.filter(t => t.measure === 'CONVERTED_CASH_NET_BASE');
    assert.equal(converted.length, 1);
    assert.equal(converted[0].currencyCode, 'DOP');
    assert.equal(converted[0].amount, '550');
    assert.equal(fixture.expected.historicalConvertedEquivalent.net, '550');
    assert.equal(fixture.expected.historicalConvertedEquivalent.isPhysicalDopAmount, false);
    assert.deepEqual(fixture.expected.posCashExpected, {
        status: 'REPORTED_BY_POS_CODE_COMPARISON', value: { USD: 10, DOP: -50 }, referenceCommit: posReference,
    });
    assert(!fixture.manifest.totals.some(t => t.measure === 'CASH_EXPECTED_BASE'));
}
verifyPhysicalVsConverted(usd);
assert.equal(usd.manifest.boundary.membershipStatus, 'UNKNOWN');
assert.equal(usd.manifest.coverage.membershipCoverage, 'UNKNOWN');
assert(usd.records.every(r => r.membership === 'UNKNOWN' && r.originalRevision === 'UNKNOWN'));
assert.equal(usd.records.filter(r => r.role === 'MEMBER').flatMap(r => r.original.payments || []).length, 1);
const collection = collections.records.find(r => r.kind === 'COLLECTION').original;
assert.equal(collection.allocations.reduce((sum, a) => sum + a.amount, 0), collection.appliedAmountBase);
assert.equal(collection.appliedAmountBase + collection.unappliedAmountBase, collection.receivedAmountBase);
assert.deepEqual(collections.expected.posCashExpected.value, {});
assert.equal(collections.expected.posCashExpected.referenceCommit, posReference);
assert.equal(collections.expected.uiCashExpectedDefaultBase, '0');
assert.equal(collections.expected.stats.collectionsTotal, 100);
assert.equal(collections.expected.openedAt.rule, 'CURRENT_TIME_AT_CLOSE_CREATION');
assert.equal(collections.expected.openedAtClockFixture.now, collections.expected.openedAtClockFixture.expected);
assert.notEqual(collections.expected.openedAtClockFixture.expected, collection.date);
assert.equal(collections.expected.cashExpectedIfCorrectedBase, '100');
const z = ackLost.records.find(r => r.kind === 'Z_REPORT');
assert.equal(z.originalId, ackLost.expected.originalZId);
assert.deepEqual(z.sourceEventIds, [ackLost.expected.originalZEventId]);
assert.equal(z.receipt[0].inboxStatus, 'RECEIVED');
const channels = bundle.fixtures.find(f => f.id === 'F04_CHANNELS_AND_REVISIONS');
assert.deepEqual(channels.expected.posCashExpected.value, { DOP: 1050 });
assert.equal(channels.expected.posCashExpected.referenceCommit, posReference);
assert.equal(channels.expected.refundRepresentation, 'NOT_VALIDATED_FOR_RECOVERY');
// Fixture arithmetic corroborates the result reported by POS; not an ERP implementation of the POS calculator.
assert.equal(channels.records.find(r => r.kind === 'CASH_MOVEMENT').original.amount
    + channels.records.find(r => r.kind === 'CREDIT_NOTE').original.payments[0].amount, 1050);

// Negative cases detect artifact corruption and early termination of download.
const corrupt = structuredClone(usd);
corrupt.records.find(r => r.kind === 'SALE').original.total = 551;
assert.throws(() => verifyFixture(corrupt));
const truncated = structuredClone(usd);
truncated.pages.pop();
assert.throws(() => verifyFixture(truncated));
const reordered = structuredClone(usd);
reordered.manifest.inventory.reverse();
assert.throws(() => verifyFixture(reordered));
const conflated = structuredClone(usd);
conflated.manifest.totals.find(t => t.measure === 'PHYSICAL_CASH_NET' && t.currencyCode === 'DOP').amount = '550';
assert.throws(() => verifyPhysicalVsConverted(conflated));
const authorizedByImport = structuredClone(usd);
authorizedByImport.manifest.closeAuthorization = 'GRANTED';
assert.throws(() => verifyFixture(authorizedByImport));
console.log('PASS: 4 download/import packages + 1 separate close candidate; 3 byte vectors; POS-reported F01/F02/F04; legacy UNKNOWN; no native recovery certification or close grants; 5 negative cases. POS calculator not executed here.');
