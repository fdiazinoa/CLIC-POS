// Offline J2 review: no application imports, writes, network or database.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { canonical } from './fixture-canonical.mjs';
import { buildGraph, validateGraph, validateCalculationInput } from './pos-j2-evidence/docs/pos-recovery-journal/verify-vectors.mjs';
import { buildContinuation } from './pos-j2-evidence/docs/pos-recovery-journal/verify-lineage.mjs';
const read = name => JSON.parse(readFileSync(new URL(name, import.meta.url), 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const hash = value => sha(Buffer.from(canonical(value), 'utf8'));
const evidenceRoot = 'pos-j2-evidence/';
const posRoot = evidenceRoot + 'docs/pos-recovery-journal/';
for (const line of readFileSync(new URL(evidenceRoot + 'SHA256SUMS', import.meta.url), 'utf8').trim().split('\n')) {
    const [expected, name] = line.split(/\s+/, 2);
    assert.equal(sha(readFileSync(new URL(evidenceRoot + name, import.meta.url))), expected);
}
for (const [name, expected] of Object.entries(read('published-artifacts.sha256.json').sha256)) {
    assert.equal(sha(readFileSync(new URL(name, import.meta.url))), expected, 'HISTORICAL_BYTES_CHANGED: ' + name);
}
const source = read(posRoot + 'vectors.json');
const lineage = read(posRoot + 'lineage-vectors.json');
const vectors = [...source.canonicalization, ...source.graph.vectors,
    ...read(posRoot + 'erp-own-vectors.json'), ...lineage.scenarios.flatMap(s => s.expected.vectors)];
for (const v of vectors) {
    assert.equal(canonical(v.input), v.canonicalUtf8, v.name);
    assert.equal(Buffer.from(canonical(v.input)).toString('hex'), v.utf8Hex, v.name);
    assert.equal(hash(v.input), v.sha256, v.name);
}
// Explicit expected bytes and rejection cases supplement the published corpus.
assert.equal(canonical({ 2: { 2: 'b', 10: 'a' }, 10: [2, 1] }), '{"10":[2,1],"2":{"10":"a","2":"b"}}');
assert.equal(canonical({ '\ue000': 0, '😀': 1 }), '{"😀":1,"":0}');
assert.notEqual(canonical({ 2: 'two', 10: 'ten' }), '{"2":"two","10":"ten"}');
assert.notEqual(canonical({ '\ue000': 0, '😀': 1 }), '{"":0,"😀":1}');
assert.notEqual(hash([2, 1]), hash([1, 2]));
for (const invalid of ['\ud800', '\udfff', { '\ud800': 1 }, { x: '\udfff' }, NaN, Infinity, undefined, 1n, new Date(0), { x: undefined }, Array(1)]) {
    assert.throws(() => canonical(invalid));
}
let recalculatedNegatives = 0;
// Recompute all graph digests before validation; never rely on stale hashes.
for (const [mutate, code] of [
    [i => { const o = i.configuration.calculationInputOrder; o.transactions = o.cashMovements; o.cashMovements = []; }, 'INPUT_KIND'],
    [i => { const o = i.configuration.calculationInputOrder; o.collections = o.cashMovements; o.cashMovements = []; }, 'INPUT_KIND'],
    [i => { i.configuration.calculationInputOrder.cashMovements[0].revision = '1'; }, 'INPUT_REVISION'],
    [i => { i.configuration.calculationInputOrder.cashMovements.push(i.configuration.calculationInputOrder.cashMovements[0]); }, 'INPUT_DUPLICATE'],
    [i => { i.configuration.calculationInputOrder.cashMovements = []; }, 'INPUT_OMISSION'],
]) {
    const input = structuredClone(source.input); mutate(input);
    const rebuilt = buildGraph(input);
    assert.throws(() => validateGraph(input, rebuilt), e => e.message.includes(code));
    recalculatedNegatives++;
}
for (const scenario of lineage.scenarios) {
    const { input, trustedArchiveDigest, expected } = scenario;
    assert.equal(lineage.exactZEligible, false);
    assert.equal(lineage.closeAuthorization, 'NOT_GRANTED');
    const before = canonical(input.archive);
    const previous = buildGraph(input.archive);
    const actual = buildContinuation(input, trustedArchiveDigest);
    assert.equal(canonical(actual), canonical(expected));
    assert.equal(canonical(input.archive), before);
    assert.equal(actual.manifest.members.length, 1);
    assert.equal(actual.manifest.members[0].kind, 'COLLECTION');
    assert.equal(actual.manifest.dependencies.length, 1);
    assert.equal(actual.manifest.dependencies[0].kind, 'TRANSACTION');
    assert.equal(actual.manifest.dependencies[0].revision, '3');
    assert.equal(previous.manifest.members[0].revision, '2');
    assert.equal(input.operations[0].previousContentHash, previous.manifest.members[0].originalContentHash);
    assert.equal(input.operations[0].commandId, input.operations[1].commandId);
    const anchor = input.configuration.resumeAnchor;
    assert.equal(anchor.domain, 'pos.journal.resume.v1');
    assert.equal(anchor.priorAcceptanceDigest, trustedArchiveDigest);
    assert.equal(anchor.priorChainHash, previous.seal.chainHash);
    assert.equal(actual.manifest.configurationHash, hash(input.configuration));
    const start = input.mode === 'NEW_EPOCH' ? 1n : BigInt(previous.seal.finalSequence) + 1n;
    assert.equal(BigInt(input.operations[0].sequence), start);
    const firstChain = actual.vectors.find(v => v.name === 'chain-' + start).input;
    const firstHead = input.mode === 'NEW_EPOCH'
        ? hash({ domain: 'pos.journal.genesis.v1', scope: input.scope, storageEpoch: input.storageEpoch })
        : previous.seal.chainHash;
    assert.equal(firstChain.previousChainHash, firstHead);
    assert.throws(() => buildContinuation(input, '0'.repeat(64)), e => e.message.includes('UNTRUSTED_ARCHIVE'));
    // The dependency check must hold even for an earlier revision of the same identity.
    const order = structuredClone(input.configuration.calculationInputOrder);
    order.transactions.push({ kind: 'TRANSACTION', originalId: actual.manifest.dependencies[0].originalId, revision: '2' });
    const changedConfig = { ...input.configuration, calculationInputOrder: order };
    const changedManifest = { ...actual.manifest, configurationHash: hash(changedConfig) };
    assert.throws(() => validateCalculationInput(order, changedManifest), e => e.message.includes('INPUT_DEPENDENCY'));
}
console.log(`PASS: J2 checksums; 7 historical files unchanged; ${vectors.length} cross-checked ERP byte/hash vectors; UTF-16/numeric-key positives and negatives; ${recalculatedNegatives} recomputed-graph rejections; 2 lineage scenarios and untrusted-anchor rejections. No recovery certification.`);
