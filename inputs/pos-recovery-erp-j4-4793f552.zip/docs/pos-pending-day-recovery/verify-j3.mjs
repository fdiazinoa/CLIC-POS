// Documentary specification tests only. No runtime, database, HTTP or persistence.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {canonical} from './fixture-canonical.mjs';
import {checkIntent,checkAnchor} from './pos-j3-evidence/docs/pos-recovery-j3/verify-contract.mjs';
import {buildGraph,validateGraph} from './pos-j3-evidence/docs/pos-recovery-journal/verify-vectors.mjs';
const read=n=>JSON.parse(readFileSync(new URL(n,import.meta.url),'utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const hash=v=>sha(Buffer.from(canonical(v)));
const clone=structuredClone;
const pos='pos-j3-evidence/docs/pos-recovery-j3/';
for(const line of readFileSync(new URL('pos-j3-evidence/SHA256SUMS',import.meta.url),'utf8').trim().split('\n')){
 const [h,n]=line.split(/\s+/,2);assert.equal(sha(readFileSync(new URL('pos-j3-evidence/'+n,import.meta.url))),h);
}
const spec=read(pos+'intent-contract.json'), b=read(pos+'contract-vectors.json');
assert.equal(b.exactZEligible,false);assert.equal(b.closeAuthorization,'NOT_GRANTED');
assert.deepEqual(b.commands.map(c=>c.intent.command).sort(),Object.keys(spec.commands).sort());
const assignedDraftFields=['journalSequence','newRevision','chainHash','displayNumber','displayId','sequenceNumber','seriesNumber','closedAt','openedAtFallback','manifestHash','sealHash','acceptanceDigest','transportAttempt','activationId'];
const draftRoles=new Set(['saleDraft','refundDraft','collectionDraft','cashDraft','walletDraft']);
// Narrow additional ERP review rules; NOT validators of full native artifact semantics.
function reviewBinding(i,artifacts){
 const digest=checkIntent(i,artifacts);
 assert.equal(new Date(i.preparedAt).toISOString(),i.preparedAt,'PREPARED_AT_CALENDAR');
 for(const r of i.expectedSeries)assert(r.reservationId===null||(typeof r.reservationId==='string'&&r.reservationId.trim().length>0),'EMPTY_RESERVATION');
 for(const ref of i.artifacts){
  const a=artifacts[ref.artifactHash];
  assert.deepEqual(Object.keys(a).sort(),['document','role','schemaVersion'],'ARTIFACT_ENVELOPE');
  if(draftRoles.has(a.role))for(const k of assignedDraftFields)assert(!Object.hasOwn(a.document,k),'ASSIGNED_FIELD_IN_DRAFT');
 }
 return digest;
}
function rebind(i,arts,index,mutate){
 const a=clone(arts[i.artifacts[index].artifactHash]);mutate(a);
 const digest=hash(a);arts[digest]=a;i.artifacts[index].artifactHash=digest;
 return hash(i); // all digests regenerated; rejection must be semantic/shape-specific.
}
let negatives=0, positives=0;
const fails=(fn,code)=>{assert.throws(fn,e=>e.message.includes(code));negatives++;};
for(const c of b.commands){
 assert.equal(reviewBinding(c.intent,b.artifacts),c.vector.sha256);positives++;
 assert.equal(canonical(c.intent),c.vector.canonicalUtf8);
 assert.equal(Buffer.from(canonical(c.intent)).toString('hex'),c.vector.utf8Hex);
 for(const [mutate,code] of [
  [i=>{i.version=2},'VERSION'],[i=>{i.artifacts.pop()},'ARTIFACT_ROLES'],
  [i=>{i.artifacts.push(i.artifacts[0])},'ARTIFACT_ROLES'],
  [i=>{i.activationId='assigned-later'},'INTENT_FIELDS'],
  [i=>{i.preparedAt='2026-02-30T12:00:00.000Z'},'PREPARED_AT_CALENDAR'],
  [i=>{i.expectedSeries=[{seriesId:'fixture-series',reservationId:'',expectedRevision:'1',expectedNext:'1'}]},'EMPTY_RESERVATION'],
 ]){const i=clone(c.intent);mutate(i);hash(i);fails(()=>reviewBinding(i,b.artifacts),code);}
 const i=clone(c.intent), arts=clone(b.artifacts);
 rebind(i,arts,0,a=>{a.extra='unversioned wrapper'});
 fails(()=>reviewBinding(i,arts),'ARTIFACT_ENVELOPE');
 const draftIndex=c.intent.artifacts.findIndex(a=>draftRoles.has(a.role));
 if(draftIndex>=0){
  const i=clone(c.intent), arts=clone(b.artifacts);
  rebind(i,arts,draftIndex,a=>{a.document.newRevision='8'});
  fails(()=>reviewBinding(i,arts),'ASSIGNED_FIELD_IN_DRAFT');
 }
}
// Confirm the input verifier's documented limits; no native semantic certification.
const old=clone(b.commands[0].intent);old.preparedAt='2026-02-30T12:00:00.000Z';assert(checkIntent(old,b.artifacts));
const oldRoot=clone(b.anchorRequest);oldRoot.anchor.domain='wrong';oldRoot.anchor.mode='wrong';assert.equal(checkAnchor(oldRoot,b.fixtureRegistry),'BOUND_TO_FIXTURE_ROOT_NOT_AUTHENTICATED');
// Retry decision model: stored result is authoritative; never applies an operation.
function retry(context,i,arts,stored){
 assert(context.authenticated,'AUTH_REQUIRED');
 assert.equal(canonical(context.scope),canonical(i.scope),'COMMAND_SCOPE');
 const digest=reviewBinding(i,arts);
 if(stored){
  assert.equal(stored.commandId,i.commandId,'COMMAND_LOOKUP');
  assert.equal(canonical(stored.scope),canonical(i.scope),'COMMAND_SCOPE');
  assert.equal(stored.intentHash,digest,'COMMAND_ID_CONFLICT');
  return stored.result;
 }
 return 'NEW_COMMAND_BLOCKED_PENDING_SEMANTICS_AND_CAS';
}
const root=read('j3-root.fixtures.json');
for(const c of b.commands){
 const saved={scope:c.intent.scope,commandId:c.intent.commandId,intentHash:hash(c.intent),result:{status:'FIXTURE_COMMITTED',positions:['1'],financialEventsApplied:0}};
 assert.deepEqual(retry(root.authenticatedContext,clone(c.intent),b.artifacts,saved),saved.result);
 const changed=clone(c.intent);changed.expectedSetRevision=String(BigInt(changed.expectedSetRevision)+1n);
 fails(()=>retry(root.authenticatedContext,changed,b.artifacts,saved),'COMMAND_ID_CONFLICT');
 assert.equal(retry(root.authenticatedContext,c.intent,b.artifacts,null),'NEW_COMMAND_BLOCKED_PENDING_SEMANTICS_AND_CAS');
 const i=clone(c.intent), arts=clone(b.artifacts);rebind(i,arts,0,a=>{a.document.changed='frozen-content'});
 fails(()=>retry(root.authenticatedContext,i,arts,saved),'COMMAND_ID_CONFLICT');
}
const previous=buildGraph(root.archiveInput);
const record={...root.registryTemplate,archiveHash:hash(root.archiveInput),acceptanceDigest:previous.acceptanceDigest,finalSequence:previous.seal.finalSequence,chainHash:previous.seal.chainHash,
 artifactHashes:Object.fromEntries(['configuration','declaration','report','manifest','seal'].map(n=>[n,previous.vectors.find(v=>v.name===n).sha256]))};
// Record is supplied from a synthetic independent context, not looked up in untrusted input.
function checkTrustedRoot(ctx,request,r,archive){
 assert(ctx.authenticated,'AUTH_REQUIRED');
 assert.equal(canonical(request.scope),canonical(ctx.scope),'ROOT_SCOPE');
 assert(r&&r.registryId===request.registryId,'UNKNOWN_ROOT');
 assert.equal(canonical(r.scope),canonical(ctx.scope),'ROOT_SCOPE');
 assert.equal(r.registryRevision,request.registryRevision,'ROOT_REVISION_CHANGED');
 assert.equal(r.technicalAcceptance,'ACCEPTED','ROOT_NOT_ACCEPTED');
 assert(r.retentionState==='AVAILABLE'&&archive,'ARCHIVE_UNAVAILABLE');
 assert.equal(hash(archive),r.archiveHash,'ARCHIVE_CORRUPT');
 const g=buildGraph(archive);validateGraph(archive,g);
 assert.equal(canonical(archive.scope),canonical(ctx.scope),'ROOT_SCOPE');
 assert.equal(g.acceptanceDigest,r.acceptanceDigest,'ROOT_BINDING');
 for(const [name,digest] of Object.entries(r.artifactHashes))assert.equal(g.vectors.find(v=>v.name===name).sha256,digest,'ROOT_BINDING');
 assert.equal(g.manifest.closeId,r.closeId,'ROOT_BINDING');assert.equal(g.manifest.closeEventId,r.closeEventId,'ROOT_BINDING');
 assert.equal(g.manifest.storageEpoch,r.storageEpoch,'ROOT_BINDING');assert.equal(g.manifest.openSetId,r.openSetId,'ROOT_BINDING');
 assert.equal(g.seal.finalSequence,r.finalSequence,'ROOT_BINDING');assert.equal(g.seal.chainHash,r.chainHash,'ROOT_BINDING');
 const a=request.anchor;
 assert.equal(a.domain,'pos.journal.resume.v1','ANCHOR_DOMAIN');
 assert(['NEW_EPOCH','SAME_EPOCH_SUFFIX'].includes(a.mode),'ANCHOR_MODE');
 assert.equal(canonical(a.scope),canonical(ctx.scope),'ROOT_SCOPE');
 for(const [key,source] of [['priorStorageEpoch','storageEpoch'],['priorOpenSetId','openSetId'],['priorFinalSequence','finalSequence'],['priorChainHash','chainHash'],['priorAcceptanceDigest','acceptanceDigest']])assert.equal(a[key],r[source],'ROOT_BINDING');
 assert.notEqual(a.openSetId,r.openSetId,'REUSED_OPEN_SET');
 if(a.mode==='NEW_EPOCH')assert.notEqual(a.storageEpoch,r.storageEpoch,'REUSED_EPOCH');else assert.equal(a.storageEpoch,r.storageEpoch,'WRONG_EPOCH');
 return 'FIXTURE_ARCHIVE_BOUND_NOT_AUTHENTICATED';
}
assert.equal(checkTrustedRoot(root.authenticatedContext,root.request,record,root.archiveInput),'FIXTURE_ARCHIVE_BOUND_NOT_AUTHENTICATED');
for(const t of root.rootNegatives){
 const ctx=clone(root.authenticatedContext),q=clone(root.request);let r=clone(record),a=clone(root.archiveInput);
 switch(t.change){
 case 'AUTH':ctx.authenticated=false;break;case 'ROOT_MISSING':r=null;break;case 'SCOPE':q.scope.companyId='wrong';break;
 case 'RECEIVED':r.technicalAcceptance='RECEIVED';break;case 'ARCHIVE_MISSING':a=null;break;case 'TOMBSTONE':r.retentionState='TOMBSTONE_ONLY';break;
 case 'ARCHIVE_CORRUPT':a.report.changed=true;break;case 'REVISION':q.registryRevision='2';break;case 'ANCHOR_DOMAIN':q.anchor.domain='wrong';break;
 case 'ANCHOR_MODE':q.anchor.mode='wrong';break;case 'ANCHOR_ROOT':q.anchor.priorAcceptanceDigest='0'.repeat(64);break;
 default:throw Error('Unknown fixture');
 }
 fails(()=>checkTrustedRoot(ctx,q,r,a),t.expected);
}
console.log(`PASS: J3 checksum; ${positives} intent bindings; ${negatives} independent ERP negatives including rehashed artifacts/retries and 11 root cases. Native semantics, durable provenance and operational acceptance NOT certified.`);
