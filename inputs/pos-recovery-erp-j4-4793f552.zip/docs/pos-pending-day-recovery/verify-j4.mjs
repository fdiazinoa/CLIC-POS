// Documentary J4 review only. No operational source, persistence, network or DB.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {canonical} from './fixture-canonical.mjs';
import {checkIntent,checkAnchor,assignedDraftFields} from './pos-j4-evidence/docs/pos-recovery-j3/verify-contract.mjs';
import {checkSemantics} from './pos-j4-evidence/docs/pos-recovery-j4/verify-semantics.mjs';
const read=n=>JSON.parse(readFileSync(new URL(n,import.meta.url),'utf8'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const hash=v=>sha(Buffer.from(canonical(v)));
const root='pos-j4-evidence/',old=read(root+'docs/pos-recovery-j3/contract-vectors.json'),modern=read(root+'docs/pos-recovery-j4/semantic-vectors.json');
for(const line of readFileSync(new URL(root+'SHA256SUMS',import.meta.url),'utf8').trim().split('\n')){
 const [h,n]=line.split(/\s+/,2);assert.equal(sha(readFileSync(new URL(root+n,import.meta.url))),h);
}
for(const [n,h] of Object.entries(read(root+'docs/pos-recovery-j4/published-vectors.sha256.json')))assert.equal(sha(readFileSync(new URL(root+n,import.meta.url))),h);
for(const [n,h] of Object.entries(read('published-artifacts.sha256.json').sha256))assert.equal(sha(readFileSync(new URL(n,import.meta.url))),h);
let rejected=0,bindings=0,historyPositives=0;
function fails(fn,code){assert.throws(fn,e=>e.message.includes(code));rejected++;}
function rebind(c,role,mutate){
 const ref=c.intent.artifacts.find(r=>r.role===role),a=structuredClone(c.artifacts[ref.artifactHash]);mutate(a.document,a);
 ref.artifactHash=hash(a);c.artifacts[ref.artifactHash]=a;return hash(c.intent);
}
const docs=c=>Object.fromEntries(c.intent.artifacts.map(r=>[r.role,c.artifacts[r.artifactHash].document]));
const copy=command=>structuredClone(modern.cases.find(c=>c.intent.command===command));
for(const f of old.commands){
 assert.equal(checkIntent(f.intent,old.artifacts),f.vector.sha256);bindings++;
 for(const date of ['2026-02-30T12:00:00.000Z','2026-02-29T12:00:00.000Z','2026-04-31T12:00:00.000Z']){
  const i=structuredClone(f.intent);i.preparedAt=date;hash(i);fails(()=>checkIntent(i,old.artifacts),'PREPARED_AT_CALENDAR');
 }
 for(const reservationId of ['', ' \t ']){
  const i=structuredClone(f.intent);i.expectedSeries=[{seriesId:'S',reservationId,expectedRevision:'1',expectedNext:'1'}];hash(i);fails(()=>checkIntent(i,old.artifacts),'EMPTY_RESERVATION');
 }
 const c={intent:structuredClone(f.intent),artifacts:structuredClone(old.artifacts)};
 rebind(c,c.intent.artifacts[0].role,(_d,a)=>{a.extra='rehash'});fails(()=>checkIntent(c.intent,c.artifacts),'ARTIFACT_ENVELOPE');
 for(const ref of f.intent.artifacts.filter(r=>r.role.endsWith('Draft'))){
  for(const field of assignedDraftFields){
   const c={intent:structuredClone(f.intent),artifacts:structuredClone(old.artifacts)};
   rebind(c,ref.role,d=>{d.nested={path:[{[field]:'assigned-after-hash'}]}});
   fails(()=>checkIntent(c.intent,c.artifacts),'ASSIGNED_FIELD_IN_DRAFT');
  }
 }
 const leap=structuredClone(f.intent);leap.preparedAt='2024-02-29T12:00:00.000Z';assert(checkIntent(leap,old.artifacts));
}
for(const role of ['originalBefore','documentsBefore','walletBefore','linkedDocument']){
 const f=old.commands.find(c=>c.intent.artifacts.some(r=>r.role===role));const c={intent:structuredClone(f.intent),artifacts:structuredClone(old.artifacts)};
 rebind(c,role,d=>{d.historical={seriesNumber:77,closedAt:'2025-01-01T00:00:00.000Z'}});
 const before=canonical(c.artifacts);checkIntent(c.intent,c.artifacts);assert.equal(canonical(c.artifacts),before);historyPositives++;
}
for(const [field,value,code] of [['domain','wrong','ANCHOR_DOMAIN'],['mode','wrong','ANCHOR_MODE']]){
 const q=structuredClone(old.anchorRequest);q.anchor[field]=value;hash(q);fails(()=>checkAnchor(q,old.fixtureRegistry),code);
}
// Native v1 stays separate. No conversion or mutation of historical intent vectors.
for(const c of modern.cases){
 assert.equal(checkSemantics(c.intent,c.artifacts).intentHash,c.vector.sha256);bindings++;
 assert.equal(canonical(c.intent),c.vector.canonicalUtf8);
 fails(()=>checkIntent(c.intent,c.artifacts),'DOMAIN');
 const missing=structuredClone(c);missing.intent.artifacts=missing.intent.artifacts.filter(r=>r.role!=='executionContext');hash(missing.intent);fails(()=>checkSemantics(missing.intent,missing.artifacts),'ROLES');
}
const closed=copy('CLOSE_SET');const fixed=docs(closed).closeControl;
assert.equal(new Set(Object.values(fixed)).size,3);
const saved={commandId:closed.intent.commandId,intentHash:hash(closed.intent),result:{...fixed,fixtureNumber:'11',committedInTest:false}};
function retry(c,stored){
 checkSemantics(c.intent,c.artifacts);assert.equal(c.intent.commandId,stored.commandId,'COMMAND_LOOKUP');
 assert.equal(hash(c.intent),stored.intentHash,'COMMAND_ID_CONFLICT');return stored.result;
}
assert.deepEqual(retry(structuredClone(closed),saved),saved.result);
for(const key of ['closeId','closeEventId','nextOpenSetId']){
 const c=copy('CLOSE_SET');rebind(c,'closeControl',x=>{x[key]='23232323-2323-4323-8323-232323232323'});
 checkSemantics(c.intent,c.artifacts);assert.notEqual(hash(c.intent),saved.intentHash);
 fails(()=>retry(c,saved),'COMMAND_ID_CONFLICT');
}
// Fully consistent two-series declaration must still be blocked by the variant limit.
const multi=copy('CLOSE_SET');multi.intent.expectedSeries.push({...multi.intent.expectedSeries[0],seriesId:'ZZ-SECOND'});
rebind(multi,'executionContext',d=>{d.numbering.allocations.push({...d.numbering.allocations[0],seriesId:'ZZ-SECOND'})});
fails(()=>checkSemantics(multi.intent,multi.artifacts),'MULTIPLE_SERIES_UNAGREED');
// Extra ERP rules are bounded documentary guards, not a replacement POS calculator.
function review(c){
 const result=checkSemantics(c.intent,c.artifacts),d=docs(c);
 if(d.refundDraft){
  const totals=new Map();
  for(const line of d.refundDraft.items){const k=JSON.stringify([line.id,line.originalCartId]);totals.set(k,(totals.get(k)||0)+line.quantity);}
  for(const [k,quantity] of totals){const [id,cartId]=JSON.parse(k),before=d.originalBefore.snapshot.items.find(x=>x.id===id&&x.cartId===cartId);assert(before&&quantity<=before.remainingRefundQuantity,'REFUND_AGGREGATE_LIMIT');}
 }
 // TRACKED needs a complete inventory/UOM/recipe policy; no invented universal delta formula.
 if(d.inventoryPlan)assert(d.inventoryPlan.mode==='NONE','UNSUPPORTED_TRACKED_INVENTORY_PROFILE');
 const transaction=d.saleDraft||d.refundDraft;
 if(transaction)for(const p of transaction.payments)if(p.changeAmount>0)assert(p.changeCurrencyCode==='DOP','UNSUPPORTED_CHANGE_CURRENCY');
 return {...result,status:'ERP_DOCUMENTARY_SUBSET_NOT_AUTHORIZED'};
}
let gapCases=0;
const excessive=copy('REFUND_CREATE');
rebind(excessive,'refundDraft',x=>{x.items=[{...x.items[0],quantity:2},{...x.items[0],cartId:'LINE-2',quantity:2}];x.total=x.netAmount=400;x.payments[0].amount=x.payments[0].appliedAmountBase=400});
assert.equal(checkSemantics(excessive.intent,excessive.artifacts).status,'SEMANTIC_FIXTURE_VALID_NOT_AUTHORIZED');fails(()=>review(excessive),'REFUND_AGGREGATE_LIMIT');gapCases++;
const validSplit=copy('REFUND_CREATE');
rebind(validSplit,'refundDraft',x=>{x.items=[x.items[0],{...x.items[0],cartId:'LINE-2'}];x.total=x.netAmount=200;x.payments[0].amount=x.payments[0].appliedAmountBase=200});review(validSplit);
const stock=copy('SALE_CREATE');rebind(stock,'executionContext',x=>{x.inventoryMode='TRACKED'});
rebind(stock,'inventoryPlan',x=>{x.mode='TRACKED';x.lines=[{cartId:'LINE-1',productId:'PRODUCT-1',warehouseId:'W',unit:'UNIT',delta:999}]});
checkSemantics(stock.intent,stock.artifacts);fails(()=>review(stock),'UNSUPPORTED_TRACKED_INVENTORY_PROFILE');gapCases++;
const change=copy('SALE_CREATE');rebind(change,'saleDraft',x=>{x.payments[0].amount=110;x.payments[0].changeAmount=10;x.payments[0].changeCurrencyCode='USD'});
checkSemantics(change.intent,change.artifacts);fails(()=>review(change),'UNSUPPORTED_CHANGE_CURRENCY');gapCases++;
const validChange=copy('SALE_CREATE');rebind(validChange,'saleDraft',x=>{x.payments[0].amount=110;x.payments[0].changeAmount=10;x.payments[0].changeCurrencyCode='DOP'});review(validChange);
for(const c of modern.cases)review(c);
console.log(`PASS: checksums and historical bytes; ${bindings} v1/v2 bindings; ${historyPositives} historical-role positives; ${rejected} independent rehashed negatives; ${gapCases} new POS limitations reproduced and blocked by documentary ERP guards. No runtime or recovery authorization.`);
