"""Offline checks of supplied evidence and candidate artifacts; no POS, ERP, DB or HTTP imports.
Requires jsonschema==4.25.1. Semantic cases are specification tests, not concurrency tests.
"""
import copy
import hashlib
import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker, ValidationError

ROOT = Path(__file__).parent
read = lambda name: json.loads((ROOT / name).read_text())
evidence_root = ROOT / 'pos-r3-evidence'
for line in (evidence_root / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split(maxsplit=1)
    assert hashlib.sha256((evidence_root / name).read_bytes()).hexdigest() == digest
source = read('pos-r3-evidence/docs/pos-recovery-r3/serialization-pairs.json')
cases = {case['id']: case for case in source['cases']}
fixtures = read('r4-evidence.fixtures.json')
profiles = read('original-profiles.schema.json')
protocol = read('closure-protocol.schema.json')

def validator(schema, shape):
    return Draft202012Validator({**schema, '$ref': '#/$defs/' + shape}, format_checker=FormatChecker())

assert fixtures['agreementStatus'] == 'UNAGREED'
assert fixtures['sourceCommit'] == source['sourceCommit']
assert len(source['cases']) == 14 and len(source['timestampCases']) == 6
assessments = []
for f in fixtures['originals']:
    parts = f['evidencePointer'].split('/')
    assert f['original'] == source['cases'][int(parts[2])][parts[3]]
    assert f['nativeSchemaVersion'] == 'UNKNOWN'
    assert f['closeAuthorization'] == 'NOT_GRANTED' and not f['exactZEligible']
    errors = list(validator(profiles, f['candidateShape']).iter_errors(f['original']))
    assessments.append({'id': f['id'], 'candidateShape': f['candidateShape'],
                        'candidateShapePass': not errors,
                        'errors': [{'path': list(e.absolute_path), 'message': e.message} for e in errors],
                        'nativeRecoverabilityCertified': False})
assert assessments == read('r4-validation-results.json')['assessments'], 'stale R4 results'

sale = cases['SALE_DIRECT']
batch = cases['BATCH_PAYLOADS']
assert 'images' in batch['saleEventPayload']['transaction']['items'][0]
assert 'images' not in sale['serializedItem']['items'][0]
assert 'gatewayRawResponse' in batch['saleEventPayload']['transaction']['payments'][0]
assert 'gatewayRawResponse' not in sale['serializedItem']['payments'][0]
for k in ['id', 'cartId', 'name']:
    assert sale['localJson']['items'][0][k] == sale['serializedItem']['items'][0][k]
assert sale['httpBody']['items'][0]['terminalId'] == sale['httpBody']['terminalId']
assert sale['localJson']['terminalId'] != sale['httpBody']['terminalId']
for name in ['COLLECTION', 'BOOKING_ADVANCE']:
    assert cases[name]['httpBody'] is None and cases[name]['route'] is None
collection = cases['COLLECTION']['localJson']
assert sorted(a['amount'] for a in collection['allocations']) == [30, 50]
assert sum(a['amount'] for a in collection['allocations']) == collection['appliedAmountBase'] == 80
assert collection['receivedAmountBase'] == 100 and collection['unappliedAmountBase'] == 20
assert 'bookingActivityId' in cases['BOOKING_ADVANCE']['localJson']
wallet = cases['WALLET_PAYMENT']['localJson']
assert wallet['amount'] < 0 and wallet['type'] == 'PAYMENT'
assert 'currency' not in wallet and 'customerId' not in wallet
for name in ['REFUND_STORE_CREDIT', 'REFUND_CARD', 'CARD_VOID']:
    refund = cases[name]['localJson']
    assert refund['documentType'] == 'REFUND' and refund['status'] == 'REFUNDED'
    assert refund['total'] > 0 and all(i['quantity'] > 0 for i in refund['items'])
assert cases['CARD_VOID']['localJson']['payments'][0]['gatewayTransactionType'] == 'VOID'
mutation = cases['ORIGINAL_SALE_REFUND_MUTATION']
assert mutation['before']['id'] == mutation['after']['id']
assert mutation['before']['total'] == mutation['after']['total'] == 550
assert mutation['after']['status'] == 'PARTIAL_REFUND'
assert cases['FISCAL_BEFORE_POTENTIAL_RESEND']['localJson']['id'] == cases['FISCAL_AFTER_POTENTIAL_RESEND']['localJson']['id']
assert source['timestampCases'][3]['wire'] == source['timestampCases'][4]['wire'] == '2026-09-06T16:00:00.000Z'
assert source['timestampCases'][5]['wire'] is None

# Native optionality is different from exactness. Reject malformed future profiles,
# while accepting missing optional terminal/series and retaining original JSON unchanged.
transaction = copy.deepcopy(sale['localJson'])
transaction.pop('terminalId')
assert validator(profiles, 'Transaction').is_valid(transaction)
transaction['status'] = 'VOID'
assert not validator(profiles, 'Transaction').is_valid(transaction)
payment = copy.deepcopy(sale['localJson']['payments'][0])
for bad in ['CASH_UNKNOWN', 'cash']:
    payment['method'] = bad
    assert not validator(profiles, 'PaymentEntry').is_valid(payment)
payment['method'] = 'CASH'
for bad in [None, 1788666600000, '2026-09-06T16:00:00', '2026-09-06T16:00:00.1234Z']:
    payment['timestamp'] = bad
    assert not validator(profiles, 'PaymentEntry').is_valid(payment)
assert validator(profiles, 'Collection').is_valid(collection)  # series absent
z = copy.deepcopy(cases['Z_REPORT']['localJson'])
assert validator(profiles, 'ZReport').is_valid(z)
for field in ['baseCurrency', 'transactionCount']:
    bad = {k: v for k, v in z.items() if k != field}
    assert not validator(profiles, 'ZReport').is_valid(bad)

candidate = fixtures['closeCandidate']
validator(protocol, 'CloseAcceptanceCandidate').validate(candidate)

def utf16_key(value):
    try:
        return value.encode('utf-16-be', errors='strict')
    except UnicodeEncodeError as error:
        raise AssertionError('INVALID_UNICODE') from error


def identity_order_key(identity):
    return tuple(utf16_key(value) for value in identity)


def check_manifest(m):
    validator(protocol, 'CloseManifest').validate(m)
    assert m['closeId'] != m['closeEventId']
    member_keys = [(x['kind'], x['originalId'], x['revision']) for x in m['members']]
    dep_keys = [(x['kind'], x['originalId'], x['revision']) for x in m['dependencies']]
    # Scope is supplied by the authenticated candidate context; revision is not identity.
    member_ids = [(x['kind'], x['originalId']) for x in m['members']]
    dep_ids = [(x['kind'], x['originalId']) for x in m['dependencies']]
    assert len(set(member_ids)) == len(member_ids), 'DUPLICATE_MEMBER_IDENTITY'
    assert len(set(dep_ids)) == len(dep_ids), 'DUPLICATE_DEPENDENCY_IDENTITY'
    assert not set(member_ids).intersection(dep_ids), 'MEMBER_DEPENDENCY_INTERSECTION'
    # Explicit array ordering is required; JCS alone does not sort arrays.
    assert member_keys == sorted(member_keys, key=identity_order_key), 'MEMBER_ORDER'
    assert dep_keys == sorted(dep_keys, key=identity_order_key), 'DEPENDENCY_ORDER'

def check_checkpoint(c):
    validator(protocol, 'CheckpointProposal').validate(c)
    assert int(c['contiguousReceived']) <= int(c['highestReceived']) <= int(c['highestCommitted'])
    if c['finalSeal'] is None:
        assert c['unknownTailPossible']
    else:
        seal = c['finalSeal']
        assert seal['finalSequence'] == c['highestCommitted'] == c['highestReceived'] == c['contiguousReceived'], 'FINAL_SEQUENCE_MISMATCH'
        assert seal['chainHash'] == c['chainHash'], 'CHAIN_HASH_MISMATCH'
        assert not c['gaps'] and not c['unknownTailPossible']
    previous = int(c['contiguousReceived'])
    for gap in c['gaps']:
        assert previous < int(gap['from']) <= int(gap['through']) <= int(c['highestReceived'])
        previous = int(gap['through'])

def check_close_acceptance_candidate(value):
    """Validate the whole review artifact; never grants close authorization.

    PROGRESS_ONLY has a proposed cut endpoint, not a final seal. A coherent final
    candidate still lacks cryptographic, persistence and concurrency proof.
    """
    validator(protocol, 'CloseAcceptanceCandidate').validate(value)
    manifest, checkpoint = value['manifest'], value['checkpoint']
    check_manifest(manifest)
    check_checkpoint(checkpoint)
    assert checkpoint['storageEpoch'] == manifest['storageEpoch'], 'EPOCH_MISMATCH'
    assert checkpoint['openSetId'] == manifest['openSetId'], 'OPEN_SET_MISMATCH'
    assert manifest['sealedThrough'] == checkpoint['highestCommitted'], 'MANIFEST_CUT_MISMATCH'
    assert value['expectedRevisions']['configurationHash'] == manifest['configurationHash'], 'CONFIGURATION_HASH_MISMATCH'
    if value['validationStage'] == 'PROGRESS_ONLY':
        return 'PROGRESS_ONLY'
    # The schema requires a non-null finalSeal, no gaps and a known tail here.
    assert manifest['sealedThrough'] == checkpoint['finalSeal']['finalSequence'], 'MANIFEST_FINAL_SEAL_MISMATCH'
    return 'FINAL_SEAL_COHERENT_NOT_AUTHORIZED'

assert check_close_acceptance_candidate(candidate) == 'PROGRESS_ONLY'

invariants = read('r4-invariants.fixtures.json')
assert invariants['agreementStatus'] == 'UNAGREED'
assert invariants['exactZEligible'] is False
assert invariants['closeAuthorization'] == 'NOT_GRANTED'
for test in invariants['positives']:
    assert check_close_acceptance_candidate(invariants['bases'][test['base']]) == test['expected']
# History keeps revisions 1 and 2; only revision 2 is selected once for calculation.
history = invariants['revisionHistory']
selected = invariants['bases']['final']['manifest']['members']
assert [x['revision'] for x in history] == ['1', '2']
assert selected == [history[1]]
for test in invariants['negatives']:
    value = copy.deepcopy(invariants['bases'][test['base']])
    for pointer, replacement in test['replace'].items():
        parts = pointer.strip('/').split('/')
        target = value
        for part in parts[:-1]:
            target = target[part]
        target[parts[-1]] = replacement
    try:
        check_close_acceptance_candidate(value)
    except ValidationError:
        assert test['expectedFailure'] == 'SCHEMA', test['id']
    except AssertionError as error:
        assert str(error) == test['expectedFailure'], (test['id'], str(error))
    else:
        raise AssertionError('Full candidate negative accepted: ' + test['id'])

unicode_positive = 0
unicode_negative = 0
for collection in ['members', 'dependencies']:
    manifest = copy.deepcopy(candidate['manifest'])
    row = {'kind': 'TRANSACTION', 'originalId': '😀', 'revision': '1',
           'originalContentHash': 'a' * 64, 'commercialType': 'TICKET'}
    if collection == 'dependencies':
        row['role'] = 'READ_ONLY'
    manifest[collection] = [row, {**row, 'originalId': '\ue000'}]
    before = copy.deepcopy(manifest)
    check_manifest(manifest)
    assert manifest == before
    unicode_positive += 1
    for bad_rows, code in [
        (list(reversed(manifest[collection])), 'MEMBER_ORDER' if collection == 'members' else 'DEPENDENCY_ORDER'),
        ([{**row, 'originalId': '\ud800'}], 'INVALID_UNICODE'),
        ([{**row, 'originalId': '\udfff'}], 'INVALID_UNICODE'),
    ]:
        bad = copy.deepcopy(manifest)
        bad[collection] = bad_rows
        try:
            check_manifest(bad)
        except AssertionError as error:
            assert str(error) == code
            unicode_negative += 1
        else:
            raise AssertionError('Invalid Unicode/order accepted')

negatives = []
bad = copy.deepcopy(candidate['manifest']); bad['closeEventId'] = bad['closeId']; negatives.append((check_manifest, bad))
bad = copy.deepcopy(candidate['manifest']); bad['previousCloseProof'] = 'EXPLICIT_PREVIOUS'; negatives.append((check_manifest, bad))
member = {'kind': 'TRANSACTION', 'originalId': 'fixture-sale', 'revision': '1', 'originalContentHash': 'a'*64, 'commercialType': 'TICKET'}
bad = copy.deepcopy(candidate['manifest']); bad['members'] = [member, {**member, 'originalContentHash': 'b'*64}]; negatives.append((check_manifest, bad))
bad = copy.deepcopy(candidate['manifest']); bad['members'] = [member]; bad['dependencies'] = [{**member, 'role': 'READ_ONLY'}]; negatives.append((check_manifest, bad))
bad = copy.deepcopy(candidate['checkpoint']); bad['unknownTailPossible'] = False; negatives.append((check_checkpoint, bad))
bad = copy.deepcopy(candidate['checkpoint']); bad['contiguousReceived'] = '3'; negatives.append((check_checkpoint, bad))
bad = copy.deepcopy(candidate['checkpoint']); bad['finalSeal'] = {'scope': 'OPEN_SET', 'finalSequence': '1', 'chainHash': 'd'*64}; negatives.append((check_checkpoint, bad))
for verify, bad in negatives:
    try:
        verify(bad)
    except (AssertionError, ValidationError):
        pass
    else:
        raise AssertionError('negative protocol fixture accepted')

# Executable order-of-decisions specification; not a server implementation.
for c in fixtures['acceptanceDecisionCases']:
    result = ('AUTH_REJECTED' if not c['authorized'] else
              'PROVISIONAL' if not c['online'] else
              ('RETURN_PERSISTED_NO_APPLY' if c['sameHash'] else '409_ORIGINAL_ID_CONFLICT') if c['alreadyAccepted'] else
              '409_CUT_CHANGED' if not c['cutMatches'] else 'BLOCKED_PENDING_AGREEMENT')
    assert result == c['expected']
print(f"PASS: evidence SHA256SUMS; 14 serializer cases / 6 timestamps; {len(assessments)} unchanged originals; profile negatives; 7 protocol negatives; 6 acceptance decision cases; {len(invariants['positives'])} full-candidate positives / {len(invariants['negatives'])} independent negatives; {unicode_positive} UTF-16 positives / {unicode_negative} negatives. No runtime or concurrency certification.")
