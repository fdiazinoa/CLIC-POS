"""Offline schema checks. Requires jsonschema==4.25.1; no server or DB access."""
import copy
import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker

root = Path(__file__).parent
schema = json.loads((root / 'contract.schema.json').read_text())
bundle = json.loads((root / 'fixtures.json').read_text())
closure_schema = json.loads((root / 'closure-protocol.schema.json').read_text())
closure = json.loads((root / 'closure-protocol.fixtures.json').read_text())
original_schema = json.loads((root / 'original-profiles.schema.json').read_text())
profiles = json.loads((root / 'original-profiles.json').read_text())
Draft202012Validator.check_schema(schema)
Draft202012Validator.check_schema(closure_schema)
Draft202012Validator.check_schema(original_schema)

def validator(name):
    target = {**schema, '$ref': '#/$defs/' + name}
    return Draft202012Validator(target, format_checker=FormatChecker())

checked = 0
def check(name, value):
    global checked
    validator(name).validate(value)
    checked += 1

check('Request', bundle['request'])
for fixture in bundle['fixtures']:
    check('Manifest', fixture['manifest'])
    for record in fixture['records']:
        check('Record', record)
    for page in fixture['pages']:
        check('Page', page)
check('Status', bundle['statusExample'])
check('ReceiptRequest', bundle['receiptExample'])
assert 'ActivationRequest' not in schema['$defs']
assert 'ActivationResponse' not in schema['$defs']
assert 'activationAllowed' not in schema['$defs']['Status']['properties']
assert closure['agreementStatus'] == 'UNAGREED'
for name, key in [('ActivationRequest', 'activationRequestExample'),
                  ('ActivationResponse', 'candidateActivationResponseExample')]:
    target = {**closure_schema, '$ref': '#/$defs/' + name}
    Draft202012Validator(target, format_checker=FormatChecker()).validate(closure[key])
    checked += 1
candidate = closure['candidateFixture']
check('Manifest', candidate['manifest'])
for record in candidate['records']:
    check('Record', record)
for page in candidate['pages']:
    check('Page', page)
for error in bundle['errorExamples']:
    check('Error', error['body'])

bad_scope = {**bundle['request'], 'tenantId': 'untrusted'}
assert not validator('Request').is_valid(bad_scope)
bad_coverage = copy.deepcopy(bundle['fixtures'][0]['manifest'])
bad_coverage['coverage']['exactZEligible'] = True
assert not validator('Manifest').is_valid(bad_coverage)
bad_hash = copy.deepcopy(bundle['fixtures'][0]['records'][0])
bad_hash['hash'] = 'invalid'
assert not validator('Record').is_valid(bad_hash)
bad_grant = copy.deepcopy(bundle['fixtures'][0]['manifest'])
bad_grant['closeAuthorization'] = 'GRANTED'
assert not validator('Manifest').is_valid(bad_grant)
assert not validator('Request').is_valid(closure['activationRequestExample'])
physical = next(t for t in bundle['fixtures'][0]['manifest']['totals'] if t['measure'] == 'PHYSICAL_CASH_NET')
bad_units = {**physical, 'baseCurrencyCode': 'DOP'}
assert not validator('Total').is_valid(bad_units)
def original_validator(shape):
    return Draft202012Validator({**original_schema, '$ref': '#/$defs/' + shape}, format_checker=FormatChecker())

# Envelope acceptance explicitly does not certify the received operational object.
empty_original = copy.deepcopy(bundle['fixtures'][0]['records'][0])
empty_original['original'] = {}
assert validator('Record').is_valid(empty_original)
assert not original_validator('Transaction').is_valid({})
unknown_claim = copy.deepcopy(empty_original)
unknown_claim['originalSchemaVersion'] = 'UNKNOWN'
unknown_claim['originalValidation']['status'] = 'VALIDATED'
assert not validator('Record').is_valid(unknown_claim)
sale = next(r for r in bundle['fixtures'][0]['records'] if r['kind'] == 'SALE')
assert not original_validator('Transaction').is_valid(sale['original'])
payment = sale['original']['payments'][0]
assert not original_validator('PaymentEntry').is_valid(payment)  # no invented timestamp
reports = []
mapping = {p['kind']: p['candidateShape'] for p in profiles['profiles']}
for fixture in [*bundle['fixtures'], candidate]:
    for record in fixture['records']:
        shape = mapping.get(record['kind'])
        errors = list(original_validator(shape).iter_errors(record['original'])) if shape else []
        reports.append({'fixture': fixture['id'], 'kind': record['kind'], 'id': record['originalId'],
                        'candidateShape': shape, 'candidateShapePass': not errors if shape else None,
                        'errors': [{'path': list(e.absolute_path), 'message': e.message} for e in errors],
                        'nativeRecoverabilityCertified': False})
assert all(not r['nativeRecoverabilityCertified'] for r in reports)
saved_reports = json.loads((root / 'original-validation-results.json').read_text())
assert reports == saved_reports['assessments'], 'Original profile assessment artifact is stale'
print(f'PASS: three separate draft 2020-12 schemas; {checked} envelopes; 10 negative checks; {len(reports)} original assessments (none certified). POS native profiles remain unagreed.')
